import fs from 'fs';
import path from 'path';

const products = [
  { id: 'PROD-01', name: 'Wireless Noise-Canceling Headphones', category: 'Electronics', basePrice: 120, baseDemand: 180, priceSens: -0.4 },
  { id: 'PROD-02', name: 'Smart Fitness Watch', category: 'Electronics', basePrice: 160, baseDemand: 140, priceSens: -0.35 },
  { id: 'PROD-03', name: 'Mechanical Gaming Keyboard', category: 'Electronics', basePrice: 85, baseDemand: 210, priceSens: -0.3 },
  { id: 'PROD-04', name: 'Ultra-Wide Gaming Monitor', category: 'Electronics', basePrice: 320, baseDemand: 75, priceSens: -0.5 },
  { id: 'PROD-05', name: 'Ergonomic Office Mesh Chair', category: 'Home & Living', basePrice: 195, baseDemand: 95, priceSens: -0.38 },
  { id: 'PROD-06', name: 'HEPA Smart Air Purifier', category: 'Home & Living', basePrice: 145, baseDemand: 110, priceSens: -0.3 },
  { id: 'PROD-07', name: 'Performance Trail Running Shoes', category: 'Apparel', basePrice: 115, baseDemand: 230, priceSens: -0.42 },
  { id: 'PROD-08', name: 'All-Weather Insulated Jacket', category: 'Apparel', basePrice: 150, baseDemand: 130, priceSens: -0.35 },
  { id: 'PROD-09', name: 'Non-Slip Eco Yoga Mat', category: 'Sports & Fitness', basePrice: 48, baseDemand: 280, priceSens: -0.28 },
  { id: 'PROD-10', name: 'Adjustable Dumbbell Set', category: 'Sports & Fitness', basePrice: 220, baseDemand: 65, priceSens: -0.45 },
  { id: 'PROD-11', name: 'Artisan Roast Organic Coffee', category: 'Groceries', basePrice: 22, baseDemand: 460, priceSens: -0.2 },
  { id: 'PROD-12', name: 'Plant-Based Protein Bar Pack', category: 'Groceries', basePrice: 30, baseDemand: 390, priceSens: -0.22 }
];

function getSeason(month) {
  if (month >= 2 && month <= 4) return 'Spring';
  if (month >= 5 && month <= 7) return 'Summer';
  if (month >= 8 && month <= 10) return 'Autumn';
  return 'Winter';
}

function isHoliday(date) {
  const m = date.getMonth();
  const d = date.getDate();
  // New Year (Jan 1), Valentine (Feb 14), Memorial Day/End of May, Independence (Jul 4), Labor Day (Sep 1), Black Friday/Thanksgiving (Nov 24-28), Christmas (Dec 24-26)
  if (m === 0 && d === 1) return 1;
  if (m === 1 && d === 14) return 1;
  if (m === 4 && d >= 26) return 1;
  if (m === 6 && d === 4) return 1;
  if (m === 8 && d <= 5) return 1;
  if (m === 10 && d >= 22 && d <= 28) return 1;
  if (m === 11 && (d >= 23 && d <= 26)) return 1;
  return 0;
}

const rows = [];
rows.push('demand_id,date,product_id,product_category,price,previous_sales,stock_available,promotion,holiday,customers,season,previous_demand,demand');

// Generate daily records across 2025 (420 records across products)
const startDate = new Date('2025-01-01T00:00:00Z');
let demandIdCounter = 1;

// Maintain history per product
const productHistory = {};
products.forEach(p => {
  productHistory[p.id] = {
    lastDemand: p.baseDemand,
    lastSales: Math.round(p.baseDemand * 0.95)
  };
});

for (let day = 0; day < 365; day++) {
  const currDate = new Date(startDate.getTime() + day * 24 * 60 * 60 * 1000);
  const dateStr = currDate.toISOString().split('T')[0];
  const month = currDate.getMonth();
  const dayOfWeek = currDate.getDay();
  const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6) ? 1 : 0;
  const season = getSeason(month);
  const holiday = isHoliday(currDate);

  // Sample 1 to 2 products each day so we have 450+ rich chronological observations
  const pIndex1 = day % products.length;
  const pIndex2 = (day * 7 + 3) % products.length;
  const sampledIndices = [pIndex1];
  if (day % 3 === 0 && pIndex2 !== pIndex1) {
    sampledIndices.push(pIndex2);
  }

  for (const pIdx of sampledIndices) {
    const prod = products[pIdx];
    const prevD = productHistory[prod.id].lastDemand;
    const prevS = productHistory[prod.id].lastSales;

    // Promotion probability higher during holidays, weekends, or quarterly cycles
    const promoRand = Math.random();
    const promotion = (holiday === 1 || (isWeekend && promoRand < 0.45) || promoRand < 0.22) ? 1 : 0;

    // Price variation (-10% on promotion, +/- 5% natural variation)
    const priceMultiplier = promotion ? (0.88 + Math.random() * 0.05) : (0.97 + Math.random() * 0.08);
    const price = Math.round(prod.basePrice * priceMultiplier * 10) / 10;

    // Seasonal factor
    let seasonMultiplier = 1.0;
    if (prod.category === 'Sports & Fitness') {
      if (season === 'Spring' || season === 'Summer') seasonMultiplier = 1.25;
      if (season === 'Winter') seasonMultiplier = 0.85;
    } else if (prod.category === 'Apparel') {
      if (prod.id === 'PROD-08' && season === 'Winter') seasonMultiplier = 1.6;
      if (prod.id === 'PROD-07' && season === 'Summer') seasonMultiplier = 1.35;
    } else if (prod.category === 'Electronics') {
      if (season === 'Winter' || season === 'Autumn') seasonMultiplier = 1.2;
    } else if (prod.category === 'Groceries') {
      if (season === 'Winter' && prod.id === 'PROD-11') seasonMultiplier = 1.2;
    }

    // Customers footfall/activity
    const baseCustomers = Math.round(prod.baseDemand * 2.8);
    const custHolidayBoost = holiday ? 1.4 : 1.0;
    const custWeekendBoost = isWeekend ? 1.25 : 1.0;
    const custPromoBoost = promotion ? 1.3 : 1.0;
    const customers = Math.round(baseCustomers * custHolidayBoost * custWeekendBoost * custPromoBoost * (0.85 + Math.random() * 0.3));

    // Calculate realistic Target Demand
    const promoBoost = promotion ? 1.32 : 1.0;
    const holidayBoost = holiday ? 1.28 : 1.0;
    const weekendBoost = isWeekend ? 1.15 : 1.0;
    const priceDiffRatio = (price - prod.basePrice) / prod.basePrice;
    const priceEffect = 1.0 + (priceDiffRatio * prod.priceSens);
    const custEffect = Math.pow(customers / baseCustomers, 0.4);

    // Inertia from previous demand (autoregressive component 0.35)
    const latentDemand = (prod.baseDemand * 0.65 + prevD * 0.35) *
      seasonMultiplier * promoBoost * holidayBoost * weekendBoost * priceEffect * custEffect;

    const noise = (Math.random() - 0.5) * (prod.baseDemand * 0.14);
    const demand = Math.max(15, Math.round(latentDemand + noise));

    // Stock availability (usually ample, occasionally tight)
    const stockMultiplier = Math.random() < 0.12 ? (0.6 + Math.random() * 0.3) : (1.2 + Math.random() * 0.9);
    const stock_available = Math.max(25, Math.round(demand * stockMultiplier));

    const demandId = `DEM-${String(demandIdCounter++).padStart(4, '0')}`;

    rows.push(`${demandId},${dateStr},${prod.id},${prod.category},${price},${prevS},${stock_available},${promotion},${holiday},${customers},${season},${prevD},${demand}`);

    // Update product history
    productHistory[prod.id].lastDemand = demand;
    productHistory[prod.id].lastSales = Math.min(demand, stock_available);
  }
}

const outputPath = path.resolve('public/data/product_demand.csv');
fs.writeFileSync(outputPath, rows.join('\n'), 'utf8');
console.log(`Generated ${rows.length - 1} records to ${outputPath}`);
