import React, { useState, useMemo } from 'react';
import { ProcessedDemandRecord } from '../types';
import {
  Search,
  ChevronDown,
  ChevronUp,
  Filter,
  Eye,
  Calendar,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface DemandTableProps {
  records: ProcessedDemandRecord[];
  onSelectRecord: (record: ProcessedDemandRecord) => void;
}

type SortField = 'date' | 'product_id' | 'product_category' | 'price' | 'previous_sales' | 'stock_available' | 'customers' | 'demand';

export const DemandTable: React.FC<DemandTableProps> = ({ records, onSelectRecord }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [selectedPromo, setSelectedPromo] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortAsc, setSortAsc] = useState(false); // default latest first
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  const categories = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.product_category))).sort();
  }, [records]);

  const seasons = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.season))).sort();
  }, [records]);

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        searchTerm === '' ||
        r.demand_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.product_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.product_category.toLowerCase().includes(searchTerm.toLowerCase());

      const matchCat = selectedCategory === 'all' || r.product_category === selectedCategory;
      const matchSeason = selectedSeason === 'all' || r.season === selectedSeason;
      const matchPromo =
        selectedPromo === 'all' ||
        (selectedPromo === 'yes' && r.promotion === 1) ||
        (selectedPromo === 'no' && r.promotion === 0);

      return matchSearch && matchCat && matchSeason && matchPromo;
    });
  }, [records, searchTerm, selectedCategory, selectedSeason, selectedPromo]);

  const sortedRecords = useMemo(() => {
    return [...filteredRecords].sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      if (sortField === 'date') {
        valA = new Date(valA).getTime();
        valB = new Date(valB).getTime();
      }

      if (typeof valA === 'string') {
        return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }
      return sortAsc ? valA - valB : valB - valA;
    });
  }, [filteredRecords, sortField, sortAsc]);

  const totalPages = Math.max(1, Math.ceil(sortedRecords.length / pageSize));
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRecords.slice(start, start + pageSize);
  }, [sortedRecords, currentPage, pageSize]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div id="demand-explorer-section" className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
      {/* Table Filter Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="table-search-input"
            type="text"
            placeholder="Search by Product ID, Category, or Demand ID..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full text-xs font-medium pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
          />
        </div>

        {/* Dropdown Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <select
            id="filter-category"
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            id="filter-season"
            value={selectedSeason}
            onChange={(e) => {
              setSelectedSeason(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
          >
            <option value="all">All Seasons</option>
            {seasons.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          <select
            id="filter-promotion"
            value={selectedPromo}
            onChange={(e) => {
              setSelectedPromo(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
          >
            <option value="all">All Promotions</option>
            <option value="yes">Promotion: Yes</option>
            <option value="no">Promotion: No</option>
          </select>

          {(searchTerm || selectedCategory !== 'all' || selectedSeason !== 'all' || selectedPromo !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedSeason('all');
                setSelectedPromo('all');
                setCurrentPage(1);
              }}
              className="text-xs font-medium text-slate-500 hover:text-slate-800 underline px-2 py-1"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Table Container with Internal Overflow Scroll */}
      <div className="w-full min-w-0 overflow-x-auto rounded-lg border border-slate-200">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[10px]">
            <tr>
              <th
                className="py-3 px-3.5 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('date')}
              >
                <div className="flex items-center gap-1">
                  Date
                  {sortField === 'date' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('product_id')}
              >
                <div className="flex items-center gap-1">
                  Product
                  {sortField === 'product_id' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('product_category')}
              >
                <div className="flex items-center gap-1">
                  Category
                  {sortField === 'product_category' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('price')}
              >
                <div className="flex items-center justify-end gap-1">
                  Price ($)
                  {sortField === 'price' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('previous_sales')}
              >
                <div className="flex items-center justify-end gap-1">
                  Prev Sales
                  {sortField === 'previous_sales' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('stock_available')}
              >
                <div className="flex items-center justify-end gap-1">
                  Stock
                  {sortField === 'stock_available' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th className="py-3 px-3.5 text-center whitespace-nowrap">Promo</th>
              <th
                className="py-3 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                onClick={() => handleSort('customers')}
              >
                <div className="flex items-center justify-end gap-1">
                  Customers
                  {sortField === 'customers' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th
                className="py-3 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap bg-slate-100/70"
                onClick={() => handleSort('demand')}
              >
                <div className="flex items-center justify-end gap-1 text-slate-900 font-bold">
                  Demand (Target)
                  {sortField === 'demand' && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                </div>
              </th>
              <th className="py-3 px-3 text-center whitespace-nowrap">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {paginatedRecords.length > 0 ? (
              paginatedRecords.map((record) => (
                <tr
                  key={record.demand_id}
                  onClick={() => onSelectRecord(record)}
                  className="hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <td className="py-2.5 px-3.5 text-slate-600 whitespace-nowrap">
                    {record.date}
                  </td>
                  <td className="py-2.5 px-3.5 font-semibold text-slate-800 whitespace-nowrap">
                    {record.product_id}
                  </td>
                  <td className="py-2.5 px-3.5 text-slate-600 whitespace-nowrap">
                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200">
                      {record.product_category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3.5 text-right text-slate-800 font-medium whitespace-nowrap">
                    ${record.price.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3.5 text-right text-slate-600 whitespace-nowrap">
                    {record.previous_sales.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3.5 text-right text-slate-600 whitespace-nowrap">
                    {record.stock_available.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3.5 text-center whitespace-nowrap">
                    {record.promotion ? (
                      <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded">
                        Yes
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3.5 text-right text-slate-700 whitespace-nowrap">
                    {record.customers.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3.5 text-right font-bold text-slate-900 bg-slate-50/50 whitespace-nowrap">
                    {record.demand.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-center whitespace-nowrap">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectRecord(record);
                      }}
                      className="p-1 rounded text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                      title="Inspect record details"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={10} className="py-8 text-center text-xs text-slate-400">
                  No demand records match the selected filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
        <div>
          Showing {sortedRecords.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} to{' '}
          {Math.min(currentPage * pageSize, sortedRecords.length)} of {sortedRecords.length} records
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-2 font-medium text-slate-700">
            Page {currentPage} of {totalPages}
          </span>
          <button
            type="button"
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
