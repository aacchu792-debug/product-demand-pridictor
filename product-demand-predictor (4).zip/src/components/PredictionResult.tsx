import React from 'react';
import { PredictionOutput } from '../types';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Box,
  Tag,
  DollarSign,
  Users,
  ShieldCheck
} from 'lucide-react';

interface PredictionResultProps {
  prediction: PredictionOutput;
}

export const PredictionResult: React.FC<PredictionResultProps> = ({ prediction }) => {
  const {
    predictedDemand,
    rangeLow,
    rangeHigh,
    interpretation,
    interpretationColor,
    modelUsed,
    confidenceScore,
    input,
    timestamp
  } = prediction;

  const stockRatio =
    input.stockAvailable > 0 ? predictedDemand / input.stockAvailable : 1.0;
  const isStockConstrained = predictedDemand > input.stockAvailable;

  return (
    <div
      id="prediction-result-card"
      className="bg-white border border-slate-200/90 rounded-xl p-6 shadow-xs"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-6 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center font-bold">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Predicted Future Demand
            </h3>
            <p className="text-xs text-slate-500">
              Generated at {timestamp} via {modelUsed}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${interpretationColor}`}
          >
            {interpretation}
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-1 rounded-md border border-slate-200">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-600" />
            <span>R² Fit Index: {confidenceScore}%</span>
          </span>
        </div>
      </div>

      {/* Main Expected Demand Big Numbers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 rounded-xl bg-slate-50 border border-slate-200/80 mb-6">
        <div>
          <span className="text-xs font-medium uppercase tracking-wider text-slate-500">
            Expected Demand
          </span>
          <div className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mt-1.5 mb-1">
            {predictedDemand.toLocaleString()} <span className="text-xl font-medium text-slate-500">units</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Estimated single-day demand for target business scenario.
          </p>
        </div>

        <div className="border-t md:border-t-0 md:border-l border-slate-200 pt-4 md:pt-0 md:pl-6 flex flex-col justify-center">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-500">
            Estimated Model Range (±1.65 RMSE)
          </span>
          <div className="text-2xl font-bold text-slate-800 mt-1.5 mb-1">
            {rangeLow.toLocaleString()} – {rangeHigh.toLocaleString()}{' '}
            <span className="text-sm font-normal text-slate-500">units</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed mt-1">
            Derived empirically from historical test-set residual error (RMSE). Labeled as an estimated model-based interval, not a guaranteed forecast.
          </p>
        </div>
      </div>

      {/* Inventory & Stock Health Alert */}
      <div
        className={`p-4 rounded-lg border mb-6 flex items-start gap-3 text-xs ${
          isStockConstrained
            ? 'bg-amber-50 border-amber-200 text-amber-900'
            : 'bg-emerald-50 border-emerald-200 text-emerald-900'
        }`}
      >
        {isStockConstrained ? (
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        )}
        <div>
          <span className="font-semibold block">
            {isStockConstrained
              ? 'Potential Stockout Alert (Demand Exceeds Current Stock)'
              : 'Inventory Level Appears Sufficient'}
          </span>
          <span className="text-[11px] text-slate-600 block mt-0.5">
            Target stock available is {input.stockAvailable.toLocaleString()} units against expected demand of{' '}
            {predictedDemand.toLocaleString()} units ({Math.round(stockRatio * 100)}% stock coverage ratio).
          </span>
        </div>
      </div>

      {/* Contextual Input Conditions Grid */}
      <div>
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
          Evaluated Scenario Conditions
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              <Box className="w-3 h-3 text-slate-400" /> Product
            </div>
            <div className="text-xs font-semibold text-slate-800 truncate" title={input.productId}>
              {input.productId}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              <Tag className="w-3 h-3 text-slate-400" /> Category
            </div>
            <div className="text-xs font-semibold text-slate-800 truncate">
              {input.productCategory}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              <DollarSign className="w-3 h-3 text-slate-400" /> Price
            </div>
            <div className="text-xs font-semibold text-slate-800">
              ${input.price.toFixed(2)}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              <Users className="w-3 h-3 text-slate-400" /> Traffic
            </div>
            <div className="text-xs font-semibold text-slate-800">
              {input.expectedCustomers.toLocaleString()} visitors
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              <Calendar className="w-3 h-3 text-slate-400" /> Season & Date
            </div>
            <div className="text-xs font-semibold text-slate-800 truncate">
              {input.season} ({input.predictionDate})
            </div>
          </div>

          <div className="p-3 rounded-lg bg-white border border-slate-200">
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mb-1">
              Campaigns
            </div>
            <div className="text-xs font-semibold text-slate-800">
              {input.promotion ? 'Promo Active' : 'No Promo'}
              {input.holiday ? ' + Holiday' : ''}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
