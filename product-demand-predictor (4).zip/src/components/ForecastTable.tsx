import React from 'react';
import { ForecastItem } from '../types';
import { Calendar, Tag } from 'lucide-react';

interface ForecastTableProps {
  forecast: ForecastItem[];
}

export const ForecastTable: React.FC<ForecastTableProps> = ({ forecast }) => {
  if (!forecast || forecast.length === 0) {
    return null;
  }

  return (
    <div id="forecast-table-container" className="w-full min-w-0 overflow-x-auto border border-slate-200 rounded-xl">
      <table className="w-full text-left text-xs border-collapse">
        <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[10px]">
          <tr>
            <th className="py-3 px-4">Forecast Horizon</th>
            <th className="py-3 px-4">Calendar Date</th>
            <th className="py-3 px-4 text-right">Predicted Demand</th>
            <th className="py-3 px-4 text-right">Estimated Range</th>
            <th className="py-3 px-4 text-right">Customer Footfall</th>
            <th className="py-3 px-4 text-center">Day Type / Signals</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 bg-white">
          {forecast.map((item, idx) => (
            <tr
              key={item.date}
              className={`hover:bg-slate-50/80 transition-colors ${
                idx === 0 ? 'bg-emerald-50/30 font-medium' : ''
              }`}
            >
              <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                Day +{idx + 1}
              </td>
              <td className="py-3 px-4 text-slate-600 whitespace-nowrap flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {item.date}
              </td>
              <td className="py-3 px-4 text-right font-bold text-slate-900 whitespace-nowrap">
                {item.predictedDemand.toLocaleString()}{' '}
                <span className="text-[10px] text-slate-500 font-normal">units</span>
              </td>
              <td className="py-3 px-4 text-right text-slate-600 whitespace-nowrap text-[11px]">
                {item.rangeLow.toLocaleString()} – {item.rangeHigh.toLocaleString()}
              </td>
              <td className="py-3 px-4 text-right text-slate-700 whitespace-nowrap">
                {item.customersEst.toLocaleString()}
              </td>
              <td className="py-3 px-4 text-center whitespace-nowrap">
                <div className="flex items-center justify-center gap-1.5 flex-wrap">
                  {item.isWeekend && (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
                      Weekend
                    </span>
                  )}
                  {item.promotion ? (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Promo
                    </span>
                  ) : null}
                  {item.holiday ? (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-purple-50 text-purple-700 border border-purple-200">
                      Holiday
                    </span>
                  ) : null}
                  {!item.isWeekend && !item.promotion && !item.holiday && (
                    <span className="text-slate-400 text-[11px]">Standard</span>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
