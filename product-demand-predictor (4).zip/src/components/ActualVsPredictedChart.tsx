import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from 'recharts';
import { ModelComparisonResult } from '../types';

interface ActualVsPredictedChartProps {
  comparison: ModelComparisonResult;
}

export const ActualVsPredictedChart: React.FC<ActualVsPredictedChartProps> = ({ comparison }) => {
  const [activeModel, setActiveModel] = useState<'rf' | 'lr'>('rf');

  const lrEval = comparison.linearRegression.evaluation;
  const rfEval = comparison.randomForest.evaluation;
  const currEval = activeModel === 'rf' ? rfEval : lrEval;

  const points = currEval.testActuals.map((act, i) => ({
    actual: act,
    predicted: currEval.testPredictions[i] ?? 0,
    residual: currEval.residuals[i] ?? 0,
    sampleId: i + 1
  }));

  const maxVal = Math.max(
    ...currEval.testActuals,
    ...currEval.testPredictions,
    100
  );
  const domainLimit = Math.ceil(maxVal * 1.08);

  const customTooltip = ({ active, payload }: any) => {
    if (!active || !payload || payload.length === 0) return null;
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white text-xs p-3 rounded-lg shadow-lg border border-slate-800 space-y-1">
        <div className="font-semibold text-slate-300 border-b border-slate-800 pb-1">
          Holdout Sample #{data.sampleId}
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-slate-400">Actual Demand:</span>
          <span className="font-bold text-white">{data.actual} units</span>
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-slate-400">Model Predicted:</span>
          <span className="font-bold text-emerald-400">{data.predicted} units</span>
        </div>
        <div className="flex justify-between gap-4 text-[11px] pt-1 border-t border-slate-800">
          <span className="text-slate-400">Residual Error:</span>
          <span className={data.residual >= 0 ? 'text-amber-400' : 'text-blue-400'}>
            {data.residual > 0 ? `+${data.residual}` : data.residual} units
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="text-xs text-slate-500">
          Closer to the 45° line indicates higher predictive precision.
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveModel('rf')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              activeModel === 'rf'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
          <button
            type="button"
            onClick={() => setActiveModel('lr')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              activeModel === 'lr'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Regression
          </button>
        </div>
      </div>

      <div className="w-full h-72 min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis
              type="number"
              dataKey="actual"
              name="Actual Demand"
              domain={[0, domainLimit]}
              tick={{ fontSize: 11, fill: '#64748b' }}
              stroke="#cbd5e1"
              label={{
                value: 'Actual Demand (Units)',
                position: 'insideBottom',
                offset: -12,
                fontSize: 11,
                fill: '#64748b'
              }}
            />
            <YAxis
              type="number"
              dataKey="predicted"
              name="Predicted Demand"
              domain={[0, domainLimit]}
              tick={{ fontSize: 11, fill: '#64748b' }}
              stroke="#cbd5e1"
              label={{
                value: 'Predicted Demand (Units)',
                angle: -90,
                position: 'insideLeft',
                offset: 5,
                fontSize: 11,
                fill: '#64748b'
              }}
            />
            <Tooltip content={customTooltip} />

            {/* 45 Degree Line of Perfect Prediction (y = x) */}
            <ReferenceLine
              segment={[
                { x: 0, y: 0 },
                { x: domainLimit, y: domainLimit }
              ]}
              stroke="#94a3b8"
              strokeDasharray="4 4"
              strokeWidth={1.5}
            />

            <Scatter
              name="Predictions"
              data={points}
              fill={activeModel === 'rf' ? '#10b981' : '#3b82f6'}
              fillOpacity={0.75}
            />
          </ScatterChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 text-center text-[11px] text-slate-400">
        Dotted line represents perfect 1:1 prediction fit (Actual = Predicted).
      </div>
    </div>
  );
};
