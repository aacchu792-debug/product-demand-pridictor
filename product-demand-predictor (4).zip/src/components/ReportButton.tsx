import React, { useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import { generatePdfReport, ReportData } from '../utils/reportGenerator';

interface ReportButtonProps {
  id?: string;
  data: ReportData;
  className?: string;
  variant?: 'primary' | 'secondary' | 'compact';
}

export const ReportButton: React.FC<ReportButtonProps> = ({
  id = 'btn-download-pdf-report',
  data,
  className = '',
  variant = 'secondary'
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleDownload = async () => {
    setIsGenerating(true);
    setErrorMessage(null);
    try {
      await generatePdfReport(data);
    } catch (err: any) {
      setErrorMessage(err.message || 'Unable to generate the report. Please try again.');
      setTimeout(() => setErrorMessage(null), 4000);
    } finally {
      setIsGenerating(false);
    }
  };

  const baseClasses =
    'inline-flex items-center justify-center font-medium text-xs transition-colors rounded-lg disabled:opacity-60 disabled:cursor-not-allowed whitespace-nowrap';

  const variantClasses = {
    primary: 'bg-slate-900 text-white hover:bg-slate-800 px-4 py-2 shadow-xs',
    secondary:
      'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 hover:text-slate-900 px-3.5 py-1.5 shadow-xs',
    compact: 'bg-slate-100 text-slate-700 hover:bg-slate-200 px-3 py-1.5'
  }[variant];

  return (
    <div className="relative inline-block">
      <button
        id={id}
        type="button"
        onClick={handleDownload}
        disabled={isGenerating}
        className={`${baseClasses} ${variantClasses} ${className}`}
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
            <span>Generating PDF...</span>
          </>
        ) : (
          <>
            <Download className="w-3.5 h-3.5 mr-1.5" />
            <span>Download PDF Report</span>
          </>
        )}
      </button>

      {errorMessage && (
        <div className="absolute right-0 top-full mt-2 w-64 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg shadow-md z-50 animate-fade-in">
          {errorMessage}
        </div>
      )}
    </div>
  );
};
