import React, { useState, useEffect } from 'react';
import { PredictionInput, DatasetStatistics } from '../types';
import { Sparkles, ArrowRight, RotateCcw } from 'lucide-react';

interface DemandPredictionFormProps {
  stats: DatasetStatistics;
  onSubmit: (input: PredictionInput) => void;
  isPredicting?: boolean;
}

export const DemandPredictionForm: React.FC<DemandPredictionFormProps> = ({
  stats,
  onSubmit,
  isPredicting = false
}) => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const defaultProduct = stats.productsList[0] || { id: 'PROD-01', category: 'Electronics' };

  const [formData, setFormData] = useState<PredictionInput>({
    productId: defaultProduct.id,
    productCategory: defaultProduct.category,
    price: 115,
    previousSales: 160,
    previousDemand: 175,
    stockAvailable: 280,
    expectedCustomers: 520,
    promotion: 1,
    holiday: 0,
    season: 'Autumn',
    predictionDate: tomorrowStr,
    modelType: 'randomForest'
  });

  // When product changes, auto-align category
  const handleProductChange = (prodId: string) => {
    const found = stats.productsList.find((p) => p.id === prodId);
    setFormData((prev) => ({
      ...prev,
      productId: prodId,
      productCategory: found ? found.category : prev.productCategory
    }));
  };

  const handleScenarioPreset = (type: 'promo' | 'stockout' | 'holiday') => {
    if (type === 'promo') {
      setFormData((prev) => ({
        ...prev,
        promotion: 1,
        holiday: 0,
        price: Math.max(15, Math.round(prev.price * 0.85)),
        expectedCustomers: Math.round(prev.expectedCustomers * 1.4)
      }));
    } else if (type === 'holiday') {
      setFormData((prev) => ({
        ...prev,
        promotion: 1,
        holiday: 1,
        season: 'Winter',
        expectedCustomers: Math.round(prev.expectedCustomers * 1.6)
      }));
    } else if (type === 'stockout') {
      setFormData((prev) => ({
        ...prev,
        stockAvailable: 45,
        promotion: 0,
        holiday: 0
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form
      id="demand-prediction-form"
      onSubmit={handleSubmit}
      className="bg-white border border-slate-200/90 rounded-xl p-6 shadow-xs"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Prediction Parameters
          </h3>
          <p className="text-xs text-slate-500">
            Define upcoming business scenario parameters to evaluate demand response.
          </p>
        </div>

        {/* Quick Scenario Pre-fills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-medium text-slate-400 mr-1">Presets:</span>
          <button
            type="button"
            onClick={() => handleScenarioPreset('promo')}
            className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md border border-blue-200 transition-colors"
          >
            Flash Promo
          </button>
          <button
            type="button"
            onClick={() => handleScenarioPreset('holiday')}
            className="px-2.5 py-1 text-xs font-medium text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-md border border-purple-200 transition-colors"
          >
            Holiday Surge
          </button>
          <button
            type="button"
            onClick={() => handleScenarioPreset('stockout')}
            className="px-2.5 py-1 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-md border border-amber-200 transition-colors"
          >
            Low Inventory
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Product Selection */}
        <div>
          <label
            htmlFor="input-product-id"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Target Product
          </label>
          <select
            id="input-product-id"
            value={formData.productId}
            onChange={(e) => handleProductChange(e.target.value)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
          >
            {stats.productsList.map((p) => (
              <option key={p.id} value={p.id}>
                {p.id} ({p.category})
              </option>
            ))}
          </select>
        </div>

        {/* Product Category */}
        <div>
          <label
            htmlFor="input-product-category"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Product Category
          </label>
          <select
            id="input-product-category"
            value={formData.productCategory}
            onChange={(e) => setFormData({ ...formData, productCategory: e.target.value })}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
          >
            {stats.categoriesList.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Target Price */}
        <div>
          <label
            htmlFor="input-price"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Product Price ($)
          </label>
          <input
            id="input-price"
            type="number"
            min="1"
            step="0.1"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>

        {/* Historical Previous Sales */}
        <div>
          <label
            htmlFor="input-previous-sales"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Previous Sales (Units)
          </label>
          <input
            id="input-previous-sales"
            type="number"
            min="0"
            value={formData.previousSales}
            onChange={(e) =>
              setFormData({ ...formData, previousSales: parseInt(e.target.value, 10) || 0 })
            }
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>

        {/* Historical Previous Demand */}
        <div>
          <label
            htmlFor="input-previous-demand"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Previous Demand (Units)
          </label>
          <input
            id="input-previous-demand"
            type="number"
            min="0"
            value={formData.previousDemand}
            onChange={(e) =>
              setFormData({ ...formData, previousDemand: parseInt(e.target.value, 10) || 0 })
            }
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>

        {/* Stock Available */}
        <div>
          <label
            htmlFor="input-stock-available"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Available Stock (Inventory)
          </label>
          <input
            id="input-stock-available"
            type="number"
            min="0"
            value={formData.stockAvailable}
            onChange={(e) =>
              setFormData({ ...formData, stockAvailable: parseInt(e.target.value, 10) || 0 })
            }
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>

        {/* Expected Customer Footfall */}
        <div>
          <label
            htmlFor="input-customers"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Expected Customer Traffic
          </label>
          <input
            id="input-customers"
            type="number"
            min="10"
            value={formData.expectedCustomers}
            onChange={(e) =>
              setFormData({ ...formData, expectedCustomers: parseInt(e.target.value, 10) || 0 })
            }
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>

        {/* Season Selection */}
        <div>
          <label
            htmlFor="input-season"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Target Season
          </label>
          <select
            id="input-season"
            value={formData.season}
            onChange={(e) => setFormData({ ...formData, season: e.target.value })}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
          >
            <option value="Spring">Spring</option>
            <option value="Summer">Summer</option>
            <option value="Autumn">Autumn</option>
            <option value="Winter">Winter</option>
          </select>
        </div>

        {/* Prediction Date */}
        <div>
          <label
            htmlFor="input-prediction-date"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Prediction Date
          </label>
          <input
            id="input-prediction-date"
            type="date"
            value={formData.predictionDate}
            onChange={(e) => setFormData({ ...formData, predictionDate: e.target.value })}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            required
          />
        </div>
      </div>

      {/* Business Conditions & Algorithm Selector Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-5 pt-4 border-t border-slate-100">
        {/* Promotion Toggle */}
        <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200 bg-slate-50/70">
          <div>
            <div className="text-xs font-semibold text-slate-800">Promotional Campaign</div>
            <div className="text-[11px] text-slate-500">Active discount / advertising banner</div>
          </div>
          <button
            type="button"
            id="toggle-promotion"
            onClick={() => setFormData({ ...formData, promotion: formData.promotion ? 0 : 1 })}
            className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
              formData.promotion ? 'bg-emerald-600' : 'bg-slate-300'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                formData.promotion ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Holiday Toggle */}
        <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200 bg-slate-50/70">
          <div>
            <div className="text-xs font-semibold text-slate-800">Holiday Period</div>
            <div className="text-[11px] text-slate-500">Public or seasonal retail holiday</div>
          </div>
          <button
            type="button"
            id="toggle-holiday"
            onClick={() => setFormData({ ...formData, holiday: formData.holiday ? 0 : 1 })}
            className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
              formData.holiday ? 'bg-purple-600' : 'bg-slate-300'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                formData.holiday ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Machine Learning Model Selector */}
        <div className="flex flex-col justify-center p-3 rounded-lg border border-slate-200 bg-slate-50/70">
          <label
            htmlFor="select-model-type"
            className="text-xs font-semibold text-slate-800 mb-1"
          >
            Regression Model Engine
          </label>
          <select
            id="select-model-type"
            value={formData.modelType}
            onChange={(e) =>
              setFormData({
                ...formData,
                modelType: e.target.value as 'randomForest' | 'linearRegression'
              })
            }
            className="w-full text-xs font-medium bg-white border border-slate-300 rounded-md px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-slate-900"
          >
            <option value="randomForest">Random Forest Regression (Ensemble)</option>
            <option value="linearRegression">Linear Regression (Baseline OLS)</option>
          </select>
        </div>
      </div>

      {/* Action Button */}
      <div className="mt-6 flex items-center justify-end gap-3">
        <button
          type="button"
          onClick={() =>
            setFormData({
              productId: defaultProduct.id,
              productCategory: defaultProduct.category,
              price: 115,
              previousSales: 160,
              previousDemand: 175,
              stockAvailable: 280,
              expectedCustomers: 520,
              promotion: 1,
              holiday: 0,
              season: 'Autumn',
              predictionDate: tomorrowStr,
              modelType: 'randomForest'
            })
          }
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Defaults</span>
        </button>

        <button
          id="btn-predict-product-demand"
          type="submit"
          disabled={isPredicting}
          className="inline-flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-sm transition-all duration-150 disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>Predict Product Demand</span>
          <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
        </button>
      </div>
    </form>
  );
};
