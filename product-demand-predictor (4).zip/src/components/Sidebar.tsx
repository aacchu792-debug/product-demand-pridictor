import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  LineChart,
  Cpu,
  Database,
  CheckCircle2,
  Calendar
} from 'lucide-react';

export type NavigationPage = 'dashboard' | 'predictor' | 'analysis' | 'performance';

interface SidebarProps {
  currentPage: NavigationPage;
  onSelectPage: (page: NavigationPage) => void;
  datasetDateRange?: { start: string; end: string };
  totalRecords?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onSelectPage,
  datasetDateRange,
  totalRecords
}) => {
  const navItems: { id: NavigationPage; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'predictor', label: 'Demand Predictor', icon: TrendingUp },
    { id: 'analysis', label: 'Demand Analysis', icon: LineChart },
    { id: 'performance', label: 'Model Performance', icon: Cpu }
  ];

  return (
    <aside
      id="app-sidebar"
      className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 border-r border-slate-800 select-none h-screen sticky top-0"
    >
      {/* Brand & App Title */}
      <div className="px-6 py-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-white tracking-tight truncate">
              Product Demand ML
            </h1>
            <p className="text-[11px] text-slate-400 truncate">Predictive Demand Analytics</p>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
          Core Workflows
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => onSelectPage(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors text-left ${
                isActive
                  ? 'bg-slate-800 text-white shadow-xs font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
              <span className="truncate">{item.label}</span>
              {isActive && (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-auto shrink-0" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Runtime & Dataset Metadata badge */}
      <div className="p-4 m-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
        <div className="flex items-center gap-2 text-slate-300 font-medium mb-1.5">
          <Database className="w-3.5 h-3.5 text-emerald-400" />
          <span>Local In-Browser ML</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          Zero external APIs or backend. Regression & Random Forest trained on client machine.
        </p>

        {totalRecords !== undefined && (
          <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Loaded Records
            </span>
            <span className="font-semibold text-white">{totalRecords.toLocaleString()}</span>
          </div>
        )}

        {datasetDateRange && (
          <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3 text-slate-400" /> Time Horizon
            </span>
            <span className="font-medium text-slate-300 truncate max-w-[100px]" title={`${datasetDateRange.start} to ${datasetDateRange.end}`}>
              2025 Period
            </span>
          </div>
        )}
      </div>

      {/* Footer info */}
      <div className="px-5 py-3 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
        <span>Dual Regression Engine</span>
        <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">v1.2</span>
      </div>
    </aside>
  );
};
