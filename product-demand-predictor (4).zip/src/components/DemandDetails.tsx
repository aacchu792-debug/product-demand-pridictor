import React from 'react';
import { ProcessedDemandRecord } from '../types';
import { X, Calendar, DollarSign, Package, Users, Tag, CheckCircle2, AlertCircle } from 'lucide-react';

interface DemandDetailsProps {
  record: ProcessedDemandRecord | null;
  onClose: () => void;
}

export const DemandDetails: React.FC<DemandDetailsProps> = ({ record, onClose }) => {
  if (!record) return null;

  return (
    <div
      id="demand-details-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded">
                {record.demand_id}
              </span>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                {record.product_id}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Category: {record.product_category} • Recorded: {record.date}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Target Demand Highlight */}
          <div className="p-4 rounded-xl bg-slate-900 text-white flex items-center justify-between">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Actual Target Demand
              </span>
              <div className="text-3xl font-extrabold text-emerald-400 mt-0.5">
                {record.demand.toLocaleString()} <span className="text-sm font-normal text-slate-300">units</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[11px] text-slate-400">Previous Demand:</span>
              <div className="text-sm font-semibold text-slate-200">
                {record.previous_demand.toLocaleString()} units
              </div>
            </div>
          </div>

          {/* Core Metrics Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
              <div className="text-slate-500 flex items-center gap-1 mb-1">
                <DollarSign className="w-3.5 h-3.5 text-slate-400" /> Unit Price
              </div>
              <div className="font-bold text-slate-900 text-sm">${record.price.toFixed(2)}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Tier: {record.priceCategory}</div>
            </div>

            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
              <div className="text-slate-500 flex items-center gap-1 mb-1">
                <Package className="w-3.5 h-3.5 text-slate-400" /> Stock Available
              </div>
              <div className="font-bold text-slate-900 text-sm">
                {record.stock_available.toLocaleString()} units
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Stock/Demand: {record.stockToDemandRatio}x
              </div>
            </div>

            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
              <div className="text-slate-500 flex items-center gap-1 mb-1">
                <Users className="w-3.5 h-3.5 text-slate-400" /> Customer Traffic
              </div>
              <div className="font-bold text-slate-900 text-sm">
                {record.customers.toLocaleString()} visitors
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">Footfall opportunity</div>
            </div>

            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
              <div className="text-slate-500 flex items-center gap-1 mb-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" /> Seasonal Cycle
              </div>
              <div className="font-bold text-slate-900 text-sm">{record.season}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Quarter: Q{record.quarter}</div>
            </div>
          </div>

          {/* Business Conditions Badges */}
          <div className="p-4 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Campaign & Calendar Signals
            </h4>
            <div className="flex items-center gap-3 text-xs">
              <span
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md font-medium border ${
                  record.promotion
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-slate-100 text-slate-600 border-slate-200'
                }`}
              >
                {record.promotion ? <CheckCircle2 className="w-3.5 h-3.5" /> : null}
                {record.promotion ? 'Promotion Active' : 'No Promotion'}
              </span>

              <span
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md font-medium border ${
                  record.holiday
                    ? 'bg-purple-50 text-purple-700 border-purple-200'
                    : 'bg-slate-100 text-slate-600 border-slate-200'
                }`}
              >
                {record.holiday ? <CheckCircle2 className="w-3.5 h-3.5" /> : null}
                {record.holiday ? 'Holiday Period' : 'Non-Holiday'}
              </span>

              {record.isWeekend ? (
                <span className="inline-flex items-center px-2.5 py-1 rounded-md font-medium bg-amber-50 text-amber-700 border border-amber-200">
                  Weekend
                </span>
              ) : null}
            </div>
          </div>

          {/* Engineered Lag & Moving Averages */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Engineered Lag & History Signals (No Leakage)
            </h4>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-400">Lag 1-Day</div>
                <div className="font-bold text-slate-800">{record.lag_1_demand} u</div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-400">Lag 7-Day</div>
                <div className="font-bold text-slate-800">{record.lag_7_demand} u</div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-200">
                <div className="text-[10px] text-slate-400">Rolling 7-Day</div>
                <div className="font-bold text-slate-800">{record.rolling_7_day_demand} u</div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
