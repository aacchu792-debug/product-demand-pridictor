import React from 'react';
import { ReportButton } from './ReportButton';
import { ReportData } from '../utils/reportGenerator';
import { NavigationPage } from './Sidebar';
import { RefreshCw, Menu } from 'lucide-react';

interface HeaderProps {
  currentPage: NavigationPage;
  reportData: ReportData | null;
  onRefreshData?: () => void;
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  reportData,
  onRefreshData,
  onToggleMobileMenu
}) => {
  const pageTitles: Record<NavigationPage, { title: string; desc: string }> = {
    dashboard: {
      title: 'Demand Overview & KPIs',
      desc: 'Real-time statistical breakdown and demand metrics computed from historical sales data.'
    },
    predictor: {
      title: 'Demand Predictor',
      desc: 'Simulate future product scenarios and estimate expected demand with ML regression models.'
    },
    analysis: {
      title: 'Demand Analysis Explorer',
      desc: 'Examine relationships between pricing, stock, promotions, customers, and seasonal cycles.'
    },
    performance: {
      title: 'Model Performance & Comparison',
      desc: 'Evaluate MAE, RMSE, R², actual vs predicted fit, residuals, and feature importance.'
    }
  };

  const { title, desc } = pageTitles[currentPage];

  return (
    <header
      id="app-header"
      className="bg-white border-b border-slate-200/90 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 sticky top-0 z-20"
    >
      <div className="flex items-center gap-3">
        {onToggleMobileMenu && (
          <button
            type="button"
            onClick={onToggleMobileMenu}
            className="md:hidden p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
            aria-label="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">{title}</h2>
          <p className="text-xs text-slate-500 line-clamp-1">{desc}</p>
        </div>
      </div>

      <div className="flex items-center gap-2.5 shrink-0 self-start sm:self-auto">
        {onRefreshData && (
          <button
            id="btn-refresh-dataset"
            type="button"
            onClick={onRefreshData}
            title="Reload dataset & re-train models"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset / Retrain</span>
          </button>
        )}

        {reportData && (
          <ReportButton
            id="header-report-download"
            data={reportData}
            variant="primary"
          />
        )}
      </div>
    </header>
  );
};
