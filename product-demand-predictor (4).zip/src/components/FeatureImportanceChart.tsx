import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';
import { ModelComparisonResult } from '../types';

interface FeatureImportanceChartProps {
  comparison: ModelComparisonResult;
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ comparison }) => {
  const [viewMode, setViewMode] = useState<'rf' | 'lr'>('rf');

  const rfImportances = comparison.randomForest.featureImportances.slice(0, 10);
  const lrCoefficients = comparison.linearRegression.coefficients.slice(0, 10);

  const chartData =
    viewMode === 'rf'
      ? rfImportances.map((item) => ({
          name: item.label,
          value: item.importance,
          rawKey: item.feature
        })).reverse()
      : lrCoefficients.map((item) => ({
          name: item.label,
          value: item.normalizedImportance,
          coef: item.coefficient,
          rawKey: item.feature
        })).reverse();

  const customTooltip = ({ active, payload }: any) => {
    if (!active || !payload || payload.length === 0) return null;
    const pt = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white text-xs p-3 rounded-lg shadow-lg border border-slate-800 space-y-1">
        <div className="font-semibold text-slate-200 border-b border-slate-800 pb-1">
          {pt.name}
        </div>
        <div className="text-emerald-400 font-bold">
          {viewMode === 'rf'
            ? `Variance Reduction Importance: ${pt.value}%`
            : `Normalized Relative Influence: ${pt.value}%`}
        </div>
        {pt.coef !== undefined && (
          <div className="text-slate-400 text-[11px]">
            Regression Coefficient: {pt.coef > 0 ? `+${pt.coef}` : pt.coef}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="text-xs text-slate-500">
          {viewMode === 'rf'
            ? 'Measured by mean decrease in impurity (variance reduction across all ensemble trees).'
            : 'Standardized regression coefficients indicating relative feature weight.'}
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          <button
            type="button"
            onClick={() => setViewMode('rf')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              viewMode === 'rf'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
          <button
            type="button"
            onClick={() => setViewMode('lr')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              viewMode === 'lr'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Regression
          </button>
        </div>
      </div>

      <div className="w-full h-80 min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            layout="vertical"
            data={chartData}
            margin={{ top: 5, right: 30, left: 130, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
            <XAxis
              type="number"
              unit="%"
              tick={{ fontSize: 11, fill: '#64748b' }}
              stroke="#cbd5e1"
            />
            <YAxis
              type="category"
              dataKey="name"
              tick={{ fontSize: 11, fill: '#334155' }}
              stroke="#cbd5e1"
              width={125}
            />
            <Tooltip content={customTooltip} />
            <Bar
              dataKey="value"
              fill={viewMode === 'rf' ? '#10b981' : '#6366f1'}
              radius={[0, 4, 4, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 text-center text-[11px] text-slate-400">
        Top 10 strongest predictive signals identified by the trained model.
      </div>
    </div>
  );
};
