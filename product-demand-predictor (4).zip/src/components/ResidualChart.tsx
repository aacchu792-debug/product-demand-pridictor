import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from 'recharts';
import { ModelComparisonResult } from '../types';

interface ResidualChartProps {
  comparison: ModelComparisonResult;
}

export const ResidualChart: React.FC<ResidualChartProps> = ({ comparison }) => {
  const [activeModel, setActiveModel] = useState<'rf' | 'lr'>('rf');

  const lrEval = comparison.linearRegression.evaluation;
  const rfEval = comparison.randomForest.evaluation;
  const currEval = activeModel === 'rf' ? rfEval : lrEval;

  const data = currEval.testPredictions.map((pred, i) => ({
    predicted: pred,
    residual: currEval.residuals[i] ?? 0,
    actual: currEval.testActuals[i] ?? 0,
    index: i + 1
  }));

  const maxAbsRes = Math.max(
    Math.abs(currEval.maxPositiveError),
    Math.abs(currEval.maxNegativeError),
    20
  );
  const yDomain = [-Math.ceil(maxAbsRes * 1.15), Math.ceil(maxAbsRes * 1.15)];

  const customTooltip = ({ active, payload }: any) => {
    if (!active || !payload || payload.length === 0) return null;
    const pt = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white text-xs p-3 rounded-lg shadow-lg border border-slate-800 space-y-1">
        <div className="font-semibold text-slate-300 border-b border-slate-800 pb-1">
          Holdout Sample #{pt.index}
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-slate-400">Predicted Demand:</span>
          <span className="font-bold text-white">{pt.predicted} units</span>
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-slate-400">Actual Demand:</span>
          <span className="font-bold text-white">{pt.actual} units</span>
        </div>
        <div className="flex justify-between gap-4 text-[11px] pt-1 border-t border-slate-800">
          <span className="text-slate-400">Residual (Actual - Pred):</span>
          <span className={pt.residual >= 0 ? 'text-amber-400 font-bold' : 'text-blue-400 font-bold'}>
            {pt.residual > 0 ? `+${pt.residual}` : pt.residual} units
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      {/* Top summary stats row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <div className="bg-slate-50 border border-slate-200 px-2 py-1 rounded-md">
            <div className="text-[10px] text-slate-400">Mean Residual</div>
            <div className="font-bold text-slate-800 font-mono">{currEval.meanResidual} u</div>
          </div>
          <div className="bg-slate-50 border border-slate-200 px-2 py-1 rounded-md">
            <div className="text-[10px] text-slate-400">Test MAE</div>
            <div className="font-bold text-slate-800 font-mono">{currEval.mae} u</div>
          </div>
          <div className="bg-slate-50 border border-slate-200 px-2 py-1 rounded-md">
            <div className="text-[10px] text-slate-400">Max +Error</div>
            <div className="font-bold text-amber-700 font-mono">+{currEval.maxPositiveError} u</div>
          </div>
          <div className="bg-slate-50 border border-slate-200 px-2 py-1 rounded-md">
            <div className="text-[10px] text-slate-400">Max -Error</div>
            <div className="font-bold text-blue-700 font-mono">{currEval.maxNegativeError} u</div>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200 self-end sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveModel('rf')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              activeModel === 'rf'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
          <button
            type="button"
            onClick={() => setActiveModel('lr')}
            className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
              activeModel === 'lr'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Regression
          </button>
        </div>
      </div>

      <div className="w-full h-72 min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis
              type="number"
              dataKey="predicted"
              name="Predicted Demand"
              tick={{ fontSize: 11, fill: '#64748b' }}
              stroke="#cbd5e1"
              label={{
                value: 'Predicted Demand (Units)',
                position: 'insideBottom',
                offset: -12,
                fontSize: 11,
                fill: '#64748b'
              }}
            />
            <YAxis
              type="number"
              dataKey="residual"
              name="Residual Error"
              domain={yDomain}
              tick={{ fontSize: 11, fill: '#64748b' }}
              stroke="#cbd5e1"
              label={{
                value: 'Residual = (Actual - Predicted)',
                angle: -90,
                position: 'insideLeft',
                offset: 5,
                fontSize: 11,
                fill: '#64748b'
              }}
            />
            <Tooltip content={customTooltip} />

            {/* Zero error baseline */}
            <ReferenceLine y={0} stroke="#ef4444" strokeWidth={1.5} strokeDasharray="3 3" />

            <Scatter
              name="Residuals"
              data={data}
              fill={activeModel === 'rf' ? '#0284c7' : '#8b5cf6'}
              fillOpacity={0.7}
            />
          </ScatterChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 text-center text-[11px] text-slate-400">
        Random scatter evenly distributed around the horizontal zero line indicates unbiased homoscedastic errors.
      </div>
    </div>
  );
};
