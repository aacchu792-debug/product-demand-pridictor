import React from 'react';
import { ModelComparisonResult } from '../types';
import { Award, CheckCircle, Info } from 'lucide-react';

interface ModelMetricsProps {
  comparison: ModelComparisonResult;
}

export const ModelMetrics: React.FC<ModelMetricsProps> = ({ comparison }) => {
  const lr = comparison.linearRegression.evaluation;
  const rf = comparison.randomForest.evaluation;
  const best = comparison.bestModel;

  return (
    <div id="model-metrics-section" className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Regression Evaluation Metrics
          </h3>
          <p className="text-xs text-slate-500">
            Computed on chronological test holdout ({comparison.testSize} records, strictly posterior to training window).
          </p>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <Award className="w-3.5 h-3.5" />
          <span>Optimal Model: {best}</span>
        </div>
      </div>

      <div className="w-full min-w-0 overflow-x-auto border border-slate-200 rounded-lg">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[10px]">
            <tr>
              <th className="py-3 px-4">Evaluation Metric</th>
              <th className="py-3 px-4">Linear Regression (Baseline)</th>
              <th className="py-3 px-4">Random Forest (Ensemble)</th>
              <th className="py-3 px-4 text-center">Outcome</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {/* MAE */}
            <tr className="hover:bg-slate-50">
              <td className="py-3 px-4">
                <div className="font-semibold text-slate-800">MAE (Mean Absolute Error)</div>
                <div className="text-[11px] text-slate-500">Average absolute unit deviation</div>
              </td>
              <td className="py-3 px-4 font-mono font-medium text-slate-700">
                {lr.mae} units
              </td>
              <td className="py-3 px-4 font-mono font-bold text-slate-900">
                {rf.mae} units
              </td>
              <td className="py-3 px-4 text-center">
                {rf.mae < lr.mae ? (
                  <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    RF Better ({Math.round(((lr.mae - rf.mae) / lr.mae) * 100)}% lower)
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                    LR Better
                  </span>
                )}
              </td>
            </tr>

            {/* RMSE */}
            <tr className="hover:bg-slate-50">
              <td className="py-3 px-4">
                <div className="font-semibold text-slate-800">RMSE (Root Mean Squared Error)</div>
                <div className="text-[11px] text-slate-500">Penalizes larger outliers heavily</div>
              </td>
              <td className="py-3 px-4 font-mono font-medium text-slate-700">
                {lr.rmse} units
              </td>
              <td className="py-3 px-4 font-mono font-bold text-slate-900">
                {rf.rmse} units
              </td>
              <td className="py-3 px-4 text-center">
                {rf.rmse < lr.rmse ? (
                  <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    RF Better ({Math.round(((lr.rmse - rf.rmse) / lr.rmse) * 100)}% lower)
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                    LR Better
                  </span>
                )}
              </td>
            </tr>

            {/* MSE */}
            <tr className="hover:bg-slate-50">
              <td className="py-3 px-4">
                <div className="font-semibold text-slate-800">MSE (Mean Squared Error)</div>
                <div className="text-[11px] text-slate-500">Sum of squared residual errors</div>
              </td>
              <td className="py-3 px-4 font-mono font-medium text-slate-700">
                {lr.mse.toLocaleString()}
              </td>
              <td className="py-3 px-4 font-mono font-bold text-slate-900">
                {rf.mse.toLocaleString()}
              </td>
              <td className="py-3 px-4 text-center">
                {rf.mse < lr.mse ? (
                  <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    Lower Error
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                    Lower Error
                  </span>
                )}
              </td>
            </tr>

            {/* R² */}
            <tr className="hover:bg-slate-50">
              <td className="py-3 px-4">
                <div className="font-semibold text-slate-800">R² (Coefficient of Determination)</div>
                <div className="text-[11px] text-slate-500">Proportion of variance explained (0.0 to 1.0)</div>
              </td>
              <td className="py-3 px-4 font-mono font-medium text-slate-700">
                {lr.r2}
              </td>
              <td className="py-3 px-4 font-mono font-bold text-emerald-700">
                {rf.r2}
              </td>
              <td className="py-3 px-4 text-center">
                {rf.r2 >= lr.r2 ? (
                  <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    RF Explains More Variance
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                    LR Explains More Variance
                  </span>
                )}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex items-start gap-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <span>
          Train Set: {comparison.trainSize} records (first 80% chronologically) | Test Set: {comparison.testSize} records (last 20% chronologically).
          No random shuffling was performed to strictly prevent future data leakage into the evaluation.
        </span>
      </div>
    </div>
  );
};
