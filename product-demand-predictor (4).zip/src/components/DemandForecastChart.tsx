import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import { CombinedTimelinePoint } from '../utils/forecastUtils';

interface DemandForecastChartProps {
  data: CombinedTimelinePoint[];
  transitionDate?: string;
}

export const DemandForecastChart: React.FC<DemandForecastChartProps> = ({
  data,
  transitionDate
}) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        No forecast timeline data available.
      </div>
    );
  }

  const customTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload || payload.length === 0) return null;

    const histVal = payload.find((p: any) => p.dataKey === 'historicalDemand')?.value;
    const predVal = payload.find((p: any) => p.dataKey === 'predictedDemand')?.value;
    const rangeLow = payload.find((p: any) => p.dataKey === 'rangeLow')?.value;
    const rangeHigh = payload.find((p: any) => p.dataKey === 'rangeHigh')?.value;

    return (
      <div className="bg-slate-900 text-white text-xs p-3 rounded-lg shadow-lg border border-slate-800 space-y-1">
        <div className="font-semibold text-slate-200 border-b border-slate-800 pb-1 mb-1">
          {label}
        </div>
        {histVal !== undefined && histVal !== null && (
          <div className="flex items-center justify-between gap-3 text-slate-300">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-slate-400 inline-block" />
              Historical Demand:
            </span>
            <span className="font-bold text-white">{histVal.toLocaleString()} units</span>
          </div>
        )}
        {predVal !== undefined && predVal !== null && (
          <div className="flex items-center justify-between gap-3 text-emerald-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
              Predicted Demand:
            </span>
            <span className="font-bold text-white">{predVal.toLocaleString()} units</span>
          </div>
        )}
        {rangeLow !== undefined && rangeHigh !== undefined && (
          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
            Estimated Range: {rangeLow.toLocaleString()} – {rangeHigh.toLocaleString()}
          </div>
        )}
      </div>
    );
  };

  return (
    <div id="demand-forecast-chart-container" className="w-full h-80 min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart
          data={data}
          margin={{ top: 15, right: 20, left: 10, bottom: 25 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 11, fill: '#64748b' }}
            stroke="#cbd5e1"
            tickFormatter={(val) => {
              const parts = val.split('-');
              return parts.length >= 3 ? `${parts[1]}/${parts[2]}` : val;
            }}
          />
          <YAxis
            tick={{ fontSize: 11, fill: '#64748b' }}
            stroke="#cbd5e1"
            tickFormatter={(v) => `${v}`}
          />
          <Tooltip content={customTooltip} />
          <Legend
            verticalAlign="top"
            align="right"
            wrapperStyle={{ paddingBottom: 12, fontSize: 12 }}
          />

          {transitionDate && (
            <ReferenceLine
              x={transitionDate}
              stroke="#0ea5e9"
              strokeDasharray="4 4"
              label={{
                value: 'Forecast Start',
                position: 'top',
                fill: '#0284c7',
                fontSize: 11,
                fontWeight: 600
              }}
            />
          )}

          {/* Upper bound confidence fill */}
          <Area
            type="monotone"
            dataKey="rangeHigh"
            stroke="none"
            fill="#10b981"
            fillOpacity={0.12}
            name="Confidence Range"
            legendType="none"
          />

          {/* Historical Demand Solid Slate Line */}
          <Line
            type="monotone"
            dataKey="historicalDemand"
            stroke="#475569"
            strokeWidth={2.5}
            dot={{ r: 3, fill: '#475569' }}
            activeDot={{ r: 5 }}
            name="Historical Demand"
            connectNulls={false}
          />

          {/* Predicted Demand Emerald Dashed/Solid Line */}
          <Line
            type="monotone"
            dataKey="predictedDemand"
            stroke="#10b981"
            strokeWidth={2.5}
            strokeDasharray="5 4"
            dot={{ r: 4, fill: '#10b981', stroke: '#ffffff', strokeWidth: 2 }}
            activeDot={{ r: 6 }}
            name="Predicted Demand"
            connectNulls={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
