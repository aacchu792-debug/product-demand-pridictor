import React, { useState, useEffect } from 'react';
import {
  ProcessedDemandRecord,
  DatasetStatistics,
  ModelComparisonResult,
  PredictionInput,
  PredictionOutput,
  ForecastItem
} from '../types';
import { DemandPredictionForm } from '../components/DemandPredictionForm';
import { PredictionResult } from '../components/PredictionResult';
import { DemandForecastChart } from '../components/DemandForecastChart';
import { ForecastTable } from '../components/ForecastTable';
import { ChartCard } from '../components/ChartCard';
import { runPrediction } from '../utils/predictionUtils';
import { generateMultiDayForecast, buildCombinedTimeline } from '../utils/forecastUtils';
import { Calendar, Sliders, TrendingUp, Info } from 'lucide-react';

interface DemandPredictorProps {
  records: ProcessedDemandRecord[];
  stats: DatasetStatistics;
  models: ModelComparisonResult;
  currentPrediction: PredictionOutput | null;
  onPredictionChange: (pred: PredictionOutput) => void;
}

export const DemandPredictor: React.FC<DemandPredictorProps> = ({
  records,
  stats,
  models,
  currentPrediction,
  onPredictionChange
}) => {
  const [forecastHorizon, setForecastHorizon] = useState<number>(7); // 1, 7, 14, 30
  const [forecastList, setForecastList] = useState<ForecastItem[]>([]);
  const [isPredicting, setIsPredicting] = useState(false);

  // Run an initial default prediction if none exists
  useEffect(() => {
    if (!currentPrediction && stats.productsList.length > 0) {
      const defaultProd = stats.productsList[0];
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const initialInput: PredictionInput = {
        productId: defaultProd.id,
        productCategory: defaultProd.category,
        price: 115,
        previousSales: 160,
        previousDemand: 175,
        stockAvailable: 280,
        expectedCustomers: 520,
        promotion: 1,
        holiday: 0,
        season: 'Autumn',
        predictionDate: tomorrow.toISOString().split('T')[0],
        modelType: 'randomForest'
      };
      const result = runPrediction(initialInput, models, stats, records);
      onPredictionChange(result);

      const fcast = generateMultiDayForecast(initialInput, 7, models, records);
      setForecastList(fcast);
    }
  }, []);

  const handleRunPrediction = (input: PredictionInput) => {
    setIsPredicting(true);
    setTimeout(() => {
      const result = runPrediction(input, models, stats, records);
      onPredictionChange(result);

      const fcast = generateMultiDayForecast(input, forecastHorizon, models, records);
      setForecastList(fcast);
      setIsPredicting(false);
    }, 80);
  };

  const handleHorizonChange = (days: number) => {
    setForecastHorizon(days);
    if (currentPrediction) {
      const fcast = generateMultiDayForecast(currentPrediction.input, days, models, records);
      setForecastList(fcast);
    }
  };

  const combinedTimeline = currentPrediction
    ? buildCombinedTimeline(currentPrediction.input.productId, forecastList, records)
    : [];

  return (
    <div id="page-demand-predictor" className="space-y-6 animate-fade-in">
      {/* Notice Banner */}
      <div className="p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-xl text-xs text-blue-900 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold">Live Interactive Inference:</span> Adjust price, marketing promotions, holiday signals, or inventory levels below. The browser machine learning model instantly recalculates the expected demand curve and recursive forecast.
        </div>
      </div>

      {/* Grid: Form on Left/Top, Result on Right/Top */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Input Parameters Form (7 cols) */}
        <div className="lg:col-span-7">
          <DemandPredictionForm
            stats={stats}
            onSubmit={handleRunPrediction}
            isPredicting={isPredicting}
          />
        </div>

        {/* Prediction Result Display (5 cols) */}
        <div className="lg:col-span-5">
          {currentPrediction ? (
            <PredictionResult prediction={currentPrediction} />
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-400 text-xs">
              Configure parameters and click "Predict Product Demand".
            </div>
          )}
        </div>
      </div>

      {/* Multi-Day Forecast Section (Sections 24 & 25) */}
      {currentPrediction && (
        <div id="multi-day-forecast-section" className="space-y-6 pt-4">
          <ChartCard
            id="chart-multi-day-forecast"
            title="Multi-Day Demand Trajectory & Forecast Horizon"
            subtitle={`Visualizing historical trajectory for ${currentPrediction.input.productId} connected to future predicted trend`}
            badge="Autoregressive Rollout"
            action={
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
                <span className="text-[11px] font-medium text-slate-500 px-1.5 hidden sm:inline">
                  Forecast Window:
                </span>
                {[1, 7, 14, 30].map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => handleHorizonChange(days)}
                    className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors ${
                      forecastHorizon === days
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {days} {days === 1 ? 'Day' : 'Days'}
                  </button>
                ))}
              </div>
            }
          >
            <DemandForecastChart
              data={combinedTimeline}
              transitionDate={currentPrediction.input.predictionDate}
            />
          </ChartCard>

          {/* Forecast Horizon Table */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  Day-by-Day Forecast Breakdown ({forecastHorizon} Days)
                </h3>
                <p className="text-xs text-slate-500">
                  Autoregressive sequence feeding day t predicted demand into lag and rolling features for day t+1.
                </p>
              </div>
              <div className="text-xs text-slate-400 font-medium">
                Target Model: {currentPrediction.modelUsed}
              </div>
            </div>

            <ForecastTable forecast={forecastList} />
          </div>
        </div>
      )}
    </div>
  );
};
