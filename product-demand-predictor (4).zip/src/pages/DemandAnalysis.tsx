import React, { useState } from 'react';
import { ProcessedDemandRecord, DatasetStatistics } from '../types';
import { DemandTable } from '../components/DemandTable';
import { DemandDetails } from '../components/DemandDetails';
import { ChartCard } from '../components/ChartCard';
import {
  getProductDemandSummary,
  getCategoryDemandSummary,
  getPromotionDemandSummary,
  getSeasonalDemandSummary,
  getScatterPriceDemand,
  getScatterStockDemand,
  getScatterCustomerDemand
} from '../utils/demandAnalysis';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';
import { Users, Sparkles, TrendingUp, DollarSign, Package } from 'lucide-react';

interface DemandAnalysisProps {
  records: ProcessedDemandRecord[];
  stats: DatasetStatistics;
}

export const DemandAnalysis: React.FC<DemandAnalysisProps> = ({ records, stats }) => {
  const [selectedRecord, setSelectedRecord] = useState<ProcessedDemandRecord | null>(null);
  const [activeTab, setActiveTab] = useState<'explorer' | 'products' | 'drivers'>('explorer');

  const productSummary = getProductDemandSummary(records);
  const categorySummary = getCategoryDemandSummary(records);
  const promoSummary = getPromotionDemandSummary(records);
  const seasonalSummary = getSeasonalDemandSummary(records);
  const priceScatter = getScatterPriceDemand(records, 180);
  const stockScatter = getScatterStockDemand(records, 180);
  const custScatter = getScatterCustomerDemand(records, 180);

  // Calculate customer traffic stats
  const allCustomers = records.map((r) => r.customers);
  const avgCustomers = Math.round(allCustomers.reduce((a, b) => a + b, 0) / (allCustomers.length || 1));
  const sortedCust = [...allCustomers].sort((a, b) => a - b);
  const highCustThreshold = sortedCust[Math.floor(sortedCust.length * 0.75)] || 500;
  const lowCustThreshold = sortedCust[Math.floor(sortedCust.length * 0.25)] || 200;

  const highCustRecords = records.filter((r) => r.customers >= highCustThreshold);
  const lowCustRecords = records.filter((r) => r.customers <= lowCustThreshold);
  const avgHighDemand = Math.round(
    highCustRecords.reduce((a, b) => a + b.demand, 0) / (highCustRecords.length || 1)
  );
  const avgLowDemand = Math.round(
    lowCustRecords.reduce((a, b) => a + b.demand, 0) / (lowCustRecords.length || 1)
  );

  return (
    <div id="page-demand-analysis" className="space-y-6 animate-fade-in">
      {/* Sub-Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('explorer')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'explorer'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Historical Record Explorer
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('products')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'products'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Product & Category Aggregates
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('drivers')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'drivers'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Demand Drivers & Cross-Elasticity
          </button>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Total Analyzed: <span className="font-bold text-slate-800">{records.length}</span> entries
        </div>
      </div>

      {/* Tab 1: Historical Demand Explorer Table (Section 26 & 27) */}
      {activeTab === 'explorer' && (
        <div className="space-y-6">
          <DemandTable records={records} onSelectRecord={(r) => setSelectedRecord(r)} />
        </div>
      )}

      {/* Tab 2: Product & Category Level Breakdown (Section 29) */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          {/* Product-Level Table */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
            <div className="pb-3 mb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Product-Level Demand Profiles
              </h3>
              <p className="text-xs text-slate-500">
                Detailed metrics showing average, max, and min historical demand alongside price and stock positions.
              </p>
            </div>

            <div className="w-full min-w-0 overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Product ID</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4 text-right">Avg Demand</th>
                    <th className="py-3 px-4 text-right">Max Demand</th>
                    <th className="py-3 px-4 text-right">Min Demand</th>
                    <th className="py-3 px-4 text-right">Avg Unit Price</th>
                    <th className="py-3 px-4 text-right">Avg Stock</th>
                    <th className="py-3 px-4 text-right">Log Entries</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {productSummary.map((p) => (
                    <tr key={p.productId} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-800 whitespace-nowrap">
                        {p.productId}
                      </td>
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                        <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200">
                          {p.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-700 whitespace-nowrap">
                        {p.avgDemand.toLocaleString()} u
                      </td>
                      <td className="py-3 px-4 text-right font-medium text-slate-800 whitespace-nowrap">
                        {p.maxDemand.toLocaleString()} u
                      </td>
                      <td className="py-3 px-4 text-right text-slate-500 whitespace-nowrap">
                        {p.minDemand.toLocaleString()} u
                      </td>
                      <td className="py-3 px-4 text-right font-medium text-slate-800 whitespace-nowrap">
                        ${p.avgPrice.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-700 whitespace-nowrap">
                        {p.avgStock.toLocaleString()} u
                      </td>
                      <td className="py-3 px-4 text-right text-slate-500 whitespace-nowrap">
                        {p.recordCount}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Category Aggregate Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {categorySummary.map((c) => (
              <div
                key={c.category}
                className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs"
              >
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Category
                </div>
                <h4 className="text-sm font-bold text-slate-900 truncate mb-2">{c.category}</h4>
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Avg Demand:</span>
                    <span className="font-bold text-slate-900">{c.avgDemand} u</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Volume:</span>
                    <span className="font-medium text-slate-800">{c.totalDemand.toLocaleString()} u</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Avg Price:</span>
                    <span className="font-medium text-slate-800">${c.avgPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Detailed Drivers & Elasticity (Sections 30, 31, 32, 33, 34) */}
      {activeTab === 'drivers' && (
        <div className="space-y-6">
          {/* Customer Traffic & Demand Section (Section 34) */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  Customer Traffic Activity vs Demand
                </h3>
                <p className="text-xs text-slate-500">
                  Relationship between visitor footfall / digital traffic and converted product demand volume.
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <div className="bg-slate-50 border border-slate-200 px-3 py-1 rounded-md">
                  <span className="text-slate-400 mr-1">Avg Footfall:</span>
                  <span className="font-bold text-slate-800">{avgCustomers.toLocaleString()} visitors</span>
                </div>
                <div className="bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-md text-emerald-800">
                  <span className="mr-1">High-Traffic Demand:</span>
                  <span className="font-bold">{avgHighDemand.toLocaleString()} u</span>
                </div>
              </div>
            </div>

            <div className="w-full h-72 min-w-0">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 15 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis
                    type="number"
                    dataKey="customers"
                    name="Customers"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                    label={{
                      value: 'Customer Visitors / Traffic',
                      position: 'insideBottom',
                      offset: -8,
                      fontSize: 11,
                      fill: '#64748b'
                    }}
                  />
                  <YAxis
                    type="number"
                    dataKey="demand"
                    name="Demand"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                    label={{
                      value: 'Demand (Units)',
                      angle: -90,
                      position: 'insideLeft',
                      offset: 15,
                      fontSize: 11,
                      fill: '#64748b'
                    }}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                          <div className="font-semibold text-slate-200">{d.productId}</div>
                          <div className="text-slate-300 mt-1">Traffic: {d.customers} visitors</div>
                          <div className="text-emerald-400 font-bold">Demand: {d.demand} units</div>
                        </div>
                      );
                    }}
                  />
                  <Scatter name="CustomerDemand" data={custScatter} fill="#0d9488" fillOpacity={0.7} />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
            <p className="text-center text-[11px] text-slate-400 mt-2">
              Note: Higher customer traffic correlates with increased demand opportunity, though conversion varies by product pricing.
            </p>
          </div>

          {/* 2-Column Grid: Price vs Demand & Stock vs Demand */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ChartCard
              id="chart-price-elasticity-deep"
              title="Price vs Demand Elasticity"
              subtitle="Observed unit demand across differing historical price realizations"
              badge="Pricing"
            >
              <ResponsiveContainer width="100%" height={260}>
                <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis
                    type="number"
                    dataKey="price"
                    name="Price"
                    unit="$"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                  />
                  <YAxis
                    type="number"
                    dataKey="demand"
                    name="Demand"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                          <div className="font-semibold text-slate-200">{d.productId} ({d.category})</div>
                          <div className="text-slate-300 mt-1">Price: ${d.price}</div>
                          <div className="text-emerald-400 font-bold">Demand: {d.demand} units</div>
                        </div>
                      );
                    }}
                  />
                  <Scatter name="Price" data={priceScatter} fill="#2563eb" fillOpacity={0.65} />
                </ScatterChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard
              id="chart-stock-demand-deep"
              title="Inventory Coverage vs Demand"
              subtitle="Historical stock levels on-hand relative to realized demand"
              badge="Inventory"
            >
              <ResponsiveContainer width="100%" height={260}>
                <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis
                    type="number"
                    dataKey="stock"
                    name="Stock"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                  />
                  <YAxis
                    type="number"
                    dataKey="demand"
                    name="Demand"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    stroke="#cbd5e1"
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                          <div className="font-semibold text-slate-200">{d.productId}</div>
                          <div className="text-slate-300 mt-1">Stock: {d.stock} units</div>
                          <div className="text-emerald-400 font-bold">Demand: {d.demand} units</div>
                        </div>
                      );
                    }}
                  />
                  <Scatter name="Stock" data={stockScatter} fill="#7c3aed" fillOpacity={0.65} />
                </ScatterChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedRecord && (
        <DemandDetails record={selectedRecord} onClose={() => setSelectedRecord(null)} />
      )}
    </div>
  );
};
