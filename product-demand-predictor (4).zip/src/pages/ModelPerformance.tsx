import React, { useState } from 'react';
import { ModelComparisonResult, DynamicInsight } from '../types';
import { ModelMetrics } from '../components/ModelMetrics';
import { ActualVsPredictedChart } from '../components/ActualVsPredictedChart';
import { ResidualChart } from '../components/ResidualChart';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import { ChartCard } from '../components/ChartCard';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';
import { Award, Cpu, ShieldCheck, CheckCircle2, TrendingUp, Info } from 'lucide-react';

interface ModelPerformanceProps {
  comparison: ModelComparisonResult;
  insights: DynamicInsight[];
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({ comparison, insights }) => {
  const [selectedModel, setSelectedModel] = useState<'rf' | 'lr'>('rf');

  const rfEval = comparison.randomForest.evaluation;
  const lrEval = comparison.linearRegression.evaluation;
  const currEval = selectedModel === 'rf' ? rfEval : lrEval;

  const modelInsights = insights.filter((i) => i.type === 'model' || i.category.includes('Model'));

  return (
    <div id="page-model-performance" className="space-y-6 animate-fade-in">
      {/* Model Comparison Summary Header Card */}
      <div className="bg-slate-900 text-white rounded-xl p-6 border border-slate-800 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-bold text-white tracking-tight">
                Model Comparison & Chronological Validation
              </h3>
            </div>
            <p className="text-xs text-slate-400">
              Evaluated on an 80/20 chronological train/test split. Both models learned from identical standardized feature sets.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              <span>Recommended: {comparison.bestModel}</span>
            </div>
          </div>
        </div>

        {/* 2-Column Comparison Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Linear Regression Box */}
          <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200">Linear Regression (Ridge OLS)</span>
              <span className="text-[11px] font-mono text-slate-400">Parametric Baseline</span>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700">
              <div>
                <div className="text-[10px] text-slate-400">RMSE</div>
                <div className="text-sm font-bold text-white font-mono">{lrEval.rmse} u</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">MAE</div>
                <div className="text-sm font-bold text-white font-mono">{lrEval.mae} u</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">R² Score</div>
                <div className="text-sm font-bold text-white font-mono">{lrEval.r2}</div>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
              Closed-form analytical solution solving regularized normal equation (ZᵀZ + λI)w = Zᵀy with standardized inputs.
            </p>
          </div>

          {/* Random Forest Box */}
          <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-400">Random Forest Regression (Ensemble)</span>
              <span className="text-[11px] font-mono text-emerald-300">16 Decision Trees</span>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700">
              <div>
                <div className="text-[10px] text-slate-400">RMSE</div>
                <div className="text-sm font-bold text-emerald-400 font-mono">{rfEval.rmse} u</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">MAE</div>
                <div className="text-sm font-bold text-emerald-400 font-mono">{rfEval.mae} u</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">R² Score</div>
                <div className="text-sm font-bold text-emerald-400 font-mono">{rfEval.r2}</div>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
              Non-linear ensemble using bootstrapped sample trees with random feature subspaces, capturing promotional interactions.
            </p>
          </div>
        </div>
      </div>

      {/* Model Metrics Table (Section 39) */}
      <ModelMetrics comparison={comparison} />

      {/* Grid: Actual vs Predicted & Residual Analysis (Sections 36 & 37) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          id="chart-actual-vs-predicted"
          title="Actual vs Predicted Demand"
          subtitle="Scatter validation comparing test actuals against model predictions"
          badge="Goodness of Fit"
        >
          <ActualVsPredictedChart comparison={comparison} />
        </ChartCard>

        <ChartCard
          id="chart-residual-analysis"
          title="Residual Error Distribution"
          subtitle="Residuals = (Actual Demand - Predicted Demand) across holdout set"
          badge="Homoscedasticity"
        >
          <ResidualChart comparison={comparison} />
        </ChartCard>
      </div>

      {/* Grid: Feature Importance & Error Histogram (Sections 38 & 40) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Feature Importance (7 cols) */}
        <div className="lg:col-span-7">
          <ChartCard
            id="chart-feature-importance"
            title="Feature Importance & Predictor Rankings"
            subtitle="Variance reduction attribution across ensemble decision trees"
            badge="Interpretability"
          >
            <FeatureImportanceChart comparison={comparison} />
          </ChartCard>
        </div>

        {/* Forecast Error Analysis Histogram (5 cols) */}
        <div className="lg:col-span-5">
          <ChartCard
            id="chart-error-histogram"
            title="Forecast Error Histogram"
            subtitle={`Residual distribution across holdout samples for ${selectedModel === 'rf' ? 'Random Forest' : 'Linear Regression'}`}
            badge="Residual Density"
            action={
              <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedModel('rf')}
                  className={`text-xs px-2 py-0.5 rounded-md font-medium transition-colors ${
                    selectedModel === 'rf' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
                  }`}
                >
                  RF
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedModel('lr')}
                  className={`text-xs px-2 py-0.5 rounded-md font-medium transition-colors ${
                    selectedModel === 'lr' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
                  }`}
                >
                  LR
                </button>
              </div>
            }
          >
            <div className="flex flex-col h-full">
              <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                <div className="bg-slate-50 border border-slate-200 p-2 rounded-lg">
                  <div className="text-[10px] text-slate-400">Median Abs Error</div>
                  <div className="font-bold text-slate-800 font-mono">
                    {currEval.medianAbsoluteError} units
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 p-2 rounded-lg">
                  <div className="text-[10px] text-slate-400">Test Samples</div>
                  <div className="font-bold text-slate-800 font-mono">
                    {comparison.testSize} records
                  </div>
                </div>
              </div>

              <div className="w-full h-56 min-w-0">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={currEval.errorDistribution}
                    margin={{ top: 10, right: 10, left: -15, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis
                      dataKey="range"
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      stroke="#cbd5e1"
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis tick={{ fontSize: 10, fill: '#64748b' }} stroke="#cbd5e1" />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg">
                            <div className="font-semibold text-slate-200">Error Band: {d.range} units</div>
                            <div className="text-emerald-400 font-bold mt-1">
                              Frequency: {d.count} test observations
                            </div>
                          </div>
                        );
                      }}
                    />
                    <Bar
                      dataKey="count"
                      fill={selectedModel === 'rf' ? '#10b981' : '#3b82f6'}
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-2 text-center text-[11px] text-slate-400">
                Tightly centered distribution around zero reflects well-calibrated predictions.
              </div>
            </div>
          </ChartCard>
        </div>
      </div>
    </div>
  );
};
