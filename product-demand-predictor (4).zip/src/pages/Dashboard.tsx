import React from 'react';
import {
  ProcessedDemandRecord,
  DatasetStatistics,
  ModelComparisonResult,
  DynamicInsight
} from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import {
  getCategoryDemandSummary,
  getSeasonalDemandSummary,
  getPromotionDemandSummary,
  getMonthlyDemandTrend,
  getScatterPriceDemand,
  getScatterStockDemand
} from '../utils/demandAnalysis';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';
import {
  Database,
  Box,
  Layers,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  Package,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface DashboardProps {
  records: ProcessedDemandRecord[];
  stats: DatasetStatistics;
  models: ModelComparisonResult;
  insights: DynamicInsight[];
  onNavigateToPredictor: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  records,
  stats,
  models,
  insights,
  onNavigateToPredictor
}) => {
  // Chart datasets
  const monthlyTrend = getMonthlyDemandTrend(records);
  const categorySummary = getCategoryDemandSummary(records);
  const seasonalSummary = getSeasonalDemandSummary(records);
  const promoSummary = getPromotionDemandSummary(records);
  const priceScatter = getScatterPriceDemand(records, 150);
  const stockScatter = getScatterStockDemand(records, 150);

  const categoryColors = ['#0f766e', '#0369a1', '#4338ca', '#7c3aed', '#b45309'];
  const seasonColors: Record<string, string> = {
    Spring: '#10b981',
    Summer: '#f59e0b',
    Autumn: '#ea580c',
    Winter: '#3b82f6'
  };

  return (
    <div id="page-dashboard" className="space-y-6 animate-fade-in">
      {/* KPI Cards Grid (8 dynamically calculated metrics from CSV) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          id="kpi-total-records"
          title="Total Records"
          value={stats.totalRecords.toLocaleString()}
          subtitle="Validated historical demand logs"
          icon={Database}
          badge="80/20 Split"
          badgeType="neutral"
        />

        <StatCard
          id="kpi-total-products"
          title="Total Products"
          value={stats.totalProducts}
          subtitle="Distinct catalog items"
          icon={Box}
          badge={`${stats.categoriesCount} Categories`}
          badgeType="info"
        />

        <StatCard
          id="kpi-avg-demand"
          title="Average Demand"
          value={`${stats.avgDemand.toLocaleString()} u`}
          subtitle="Mean daily unit demand"
          icon={TrendingUp}
          badge="Target Mean"
          badgeType="success"
        />

        <StatCard
          id="kpi-avg-price"
          title="Average Price"
          value={`$${stats.avgPrice.toFixed(2)}`}
          subtitle={`Range: $${stats.priceQuantiles.lowMax} - $${stats.priceQuantiles.mediumMax}+`}
          icon={DollarSign}
          badge="Unit Value"
          badgeType="neutral"
        />

        <StatCard
          id="kpi-max-demand"
          title="Maximum Demand"
          value={`${stats.maxDemand.toLocaleString()} u`}
          subtitle="Peak single-day demand observed"
          icon={ArrowUpRight}
          badge="Peak Spike"
          badgeType="warning"
        />

        <StatCard
          id="kpi-min-demand"
          title="Minimum Demand"
          value={`${stats.minDemand.toLocaleString()} u`}
          subtitle="Lowest single-day demand recorded"
          icon={ArrowDownRight}
          badge="Baseline Floor"
          badgeType="neutral"
        />

        <StatCard
          id="kpi-avg-stock"
          title="Average Stock"
          value={`${stats.avgStock.toLocaleString()} u`}
          subtitle="Mean inventory availability"
          icon={Package}
          badge="Stock Health"
          badgeType="info"
        />

        <StatCard
          id="kpi-categories"
          title="Product Categories"
          value={stats.categoriesCount}
          subtitle="Diversified retail sectors"
          icon={Layers}
          badge="Categorized"
          badgeType="neutral"
        />
      </div>

      {/* Dynamic Insights Hero Banner */}
      <div
        id="dashboard-insights-card"
        className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Dynamic Statistical & ML Insights
            </h3>
          </div>
          <button
            type="button"
            onClick={onNavigateToPredictor}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
          >
            <span>Run New Scenario Prediction</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {insights.slice(0, 4).map((ins) => (
            <div
              key={ins.id}
              className="p-3.5 rounded-lg bg-slate-800/80 border border-slate-700/80 flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider block mb-1">
                  {ins.category}
                </span>
                <h4 className="text-xs font-bold text-slate-100 mb-1.5 leading-snug">
                  {ins.title}
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {ins.description}
                </p>
              </div>
              {ins.metric && (
                <div className="mt-3 pt-2 border-t border-slate-700 text-xs font-mono font-bold text-slate-200">
                  {ins.metric}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Charts Grid - Section 6 of PRD */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Demand Trend (Date -> Demand) */}
        <ChartCard
          id="chart-demand-trend"
          title="Historical Demand Trend"
          subtitle="Monthly average demand trajectory across all recorded products"
          badge="Chronological"
        >
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={monthlyTrend} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-300">{label}</div>
                      <div className="text-emerald-400 font-bold mt-1">
                        Avg Demand: {payload[0].value} units
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Total Recorded: {(payload[0].payload as any).totalDemand?.toLocaleString()} units
                      </div>
                    </div>
                  );
                }}
              />
              <Line
                type="monotone"
                dataKey="avgDemand"
                stroke="#0f172a"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#10b981', stroke: '#0f172a', strokeWidth: 1.5 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 2. Category Demand (Product Category -> Average Demand) */}
        <ChartCard
          id="chart-category-demand"
          title="Demand by Product Category"
          subtitle="Average demand volume per record across catalog departments"
          badge="Categorical"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={categorySummary} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const item = payload[0].payload as any;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-200">{label}</div>
                      <div className="text-emerald-400 font-bold mt-1">
                        Avg Demand: {item.avgDemand} units
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Total Volume: {item.totalDemand?.toLocaleString()} units ({item.count} records)
                      </div>
                    </div>
                  );
                }}
              />
              <Bar dataKey="avgDemand" radius={[4, 4, 0, 0]}>
                {categorySummary.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={categoryColors[index % categoryColors.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 3. Price vs Demand (Scatter chart) */}
        <ChartCard
          id="chart-price-vs-demand"
          title="Price vs Demand Relationship"
          subtitle="Scatter distribution of price points against demand volume"
          badge="Elasticity"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="price"
                name="Price"
                unit="$"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
              />
              <YAxis
                type="number"
                dataKey="demand"
                name="Demand"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-200">{d.productId} ({d.category})</div>
                      <div className="text-slate-300 mt-1">Price: ${d.price}</div>
                      <div className="text-emerald-400 font-bold">Demand: {d.demand} units</div>
                    </div>
                  );
                }}
              />
              <Scatter name="PriceDemand" data={priceScatter} fill="#0284c7" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 4. Promotion vs Demand (Bar chart) */}
        <ChartCard
          id="chart-promotion-vs-demand"
          title="Promotion vs Demand Comparison"
          subtitle="Impact of active promotional campaigns on demand lift"
          badge="A/B Signal"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={promoSummary} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="group" tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const item = payload[0].payload as any;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-200">{label}</div>
                      <div className="text-emerald-400 font-bold mt-1">
                        Avg Demand: {item.avgDemand} units
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Total Records: {item.count} {item.liftPct ? `(+${item.liftPct}% Lift)` : ''}
                      </div>
                    </div>
                  );
                }}
              />
              <Bar dataKey="avgDemand" radius={[4, 4, 0, 0]}>
                <Cell fill="#64748b" />
                <Cell fill="#10b981" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 5. Stock vs Demand (Scatter chart) */}
        <ChartCard
          id="chart-stock-vs-demand"
          title="Stock Availability vs Demand"
          subtitle="Cross-sectional alignment between on-hand inventory and consumer demand"
          badge="Inventory"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="stock"
                name="Stock"
                unit=" u"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
              />
              <YAxis
                type="number"
                dataKey="demand"
                name="Demand"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-200">{d.productId}</div>
                      <div className="text-slate-300 mt-1">Stock On-Hand: {d.stock} units</div>
                      <div className="text-emerald-400 font-bold">Demand: {d.demand} units</div>
                    </div>
                  );
                }}
              />
              <Scatter name="StockDemand" data={stockScatter} fill="#8b5cf6" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 6. Seasonal Demand (Bar chart) */}
        <ChartCard
          id="chart-seasonal-demand"
          title="Seasonal Demand Fluctuations"
          subtitle="Average product demand by climatological & retail season"
          badge="Seasonality"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={seasonalSummary} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="season" tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const item = payload[0].payload as any;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-800">
                      <div className="font-semibold text-slate-200">{label} Season</div>
                      <div className="text-emerald-400 font-bold mt-1">
                        Avg Demand: {item.avgDemand} units
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        Recorded Days: {item.count}
                      </div>
                    </div>
                  );
                }}
              />
              <Bar dataKey="avgDemand" radius={[4, 4, 0, 0]}>
                {seasonalSummary.map((entry) => (
                  <Cell key={entry.season} fill={seasonColors[entry.season] || '#64748b'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
};
