import {
  ForecastItem,
  PredictionInput,
  ModelComparisonResult,
  ProcessedDemandRecord
} from '../types';
import { extractDateFeatures } from '../ml/dateFeatures';
import { encodeFeatureRow } from '../ml/encoding';

function getSeasonFromMonth(month: number): string {
  if (month >= 3 && month <= 5) return 'Spring';
  if (month >= 6 && month <= 8) return 'Summer';
  if (month >= 9 && month <= 11) return 'Autumn';
  return 'Winter';
}

export function generateMultiDayForecast(
  input: PredictionInput,
  daysCount: number,
  models: ModelComparisonResult,
  historicalRecords: ProcessedDemandRecord[]
): ForecastItem[] {
  const selectedModel =
    input.modelType === 'linearRegression' ? models.linearRegression : models.randomForest;
  const rmse = selectedModel.evaluation.rmse || 25;
  const margin = Math.round(rmse * 1.645);

  const startDate = new Date(input.predictionDate || new Date().toISOString().split('T')[0]);
  const forecast: ForecastItem[] = [];

  // Working memory for autoregressive recursion
  let currLag1 = input.previousDemand;
  let currLag7 = input.previousDemand;
  const rollingWindow: number[] = [input.previousDemand, input.previousDemand, input.previousDemand];

  for (let d = 1; d <= daysCount; d++) {
    const targetDate = new Date(startDate.getTime() + (d - 1) * 24 * 60 * 60 * 1000);
    const dateStr = targetDate.toISOString().split('T')[0];
    const dateFeats = extractDateFeatures(targetDate);
    const season = getSeasonFromMonth(dateFeats.month);

    // Dynamic customer footfall with weekend boost
    const weekendMultiplier = dateFeats.isWeekend ? 1.2 : 1.0;
    const promoMultiplier = input.promotion ? 1.25 : 1.0;
    const holidayMultiplier = input.holiday ? 1.3 : 1.0;
    const customersEst = Math.round(
      input.expectedCustomers * weekendMultiplier * promoMultiplier * holidayMultiplier
    );

    const rollingAvg = Math.round(rollingWindow.reduce((a, b) => a + b, 0) / rollingWindow.length);

    const stockRatio =
      currLag1 > 0 ? Math.round((input.stockAvailable / currLag1) * 100) / 100 : 1.0;

    const featureRow = encodeFeatureRow(
      {
        price: input.price,
        previous_sales: Math.round(currLag1 * 0.95),
        previous_demand: currLag1,
        stock_available: input.stockAvailable,
        customers: customersEst,
        promotion: input.promotion,
        holiday: input.holiday,
        month: dateFeats.month,
        dayOfWeek: dateFeats.dayOfWeek,
        quarter: dateFeats.quarter,
        isWeekend: dateFeats.isWeekend,
        lag_1_demand: currLag1,
        lag_7_demand: currLag7,
        rolling_7_day_demand: rollingAvg,
        stockToDemandRatio: stockRatio,
        product_category: input.productCategory,
        season
      },
      {
        categories: models.categories,
        seasons: models.seasons
      }
    );

    const rawPred = selectedModel.predict(featureRow);
    const predDemand = Math.max(5, Math.round(rawPred));

    forecast.push({
      date: dateStr,
      dayLabel: `Day ${d} (${targetDate.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })})`,
      predictedDemand: predDemand,
      rangeLow: Math.max(0, predDemand - margin),
      rangeHigh: predDemand + margin,
      customersEst,
      promotion: input.promotion,
      holiday: input.holiday,
      isWeekend: Boolean(dateFeats.isWeekend)
    });

    // Update recursive autoregressive state
    currLag7 = d >= 7 ? forecast[d - 7].predictedDemand : currLag1;
    currLag1 = predDemand;
    rollingWindow.push(predDemand);
    if (rollingWindow.length > 7) rollingWindow.shift();
  }

  return forecast;
}

export interface CombinedTimelinePoint {
  date: string;
  historicalDemand: number | null;
  predictedDemand: number | null;
  rangeLow?: number | null;
  rangeHigh?: number | null;
  type: 'historical' | 'forecast';
}

export function buildCombinedTimeline(
  productId: string,
  forecast: ForecastItem[],
  historicalRecords: ProcessedDemandRecord[]
): CombinedTimelinePoint[] {
  const points: CombinedTimelinePoint[] = [];

  // Take recent ~14 historical records for this product
  const prodHistory = historicalRecords.filter((r) => r.product_id === productId);
  const recentHistory = prodHistory.slice(-14);

  recentHistory.forEach((r) => {
    points.push({
      date: r.date,
      historicalDemand: r.demand,
      predictedDemand: null,
      type: 'historical'
    });
  });

  // If we have at least one history point, bridge the connection so the chart line is continuous
  if (recentHistory.length > 0 && forecast.length > 0) {
    const lastHist = recentHistory[recentHistory.length - 1];
    // Add bridge point on the last historical date with both values
    points[points.length - 1] = {
      date: lastHist.date,
      historicalDemand: lastHist.demand,
      predictedDemand: lastHist.demand,
      type: 'historical'
    };
  }

  forecast.forEach((f) => {
    points.push({
      date: f.date,
      historicalDemand: null,
      predictedDemand: f.predictedDemand,
      rangeLow: f.rangeLow,
      rangeHigh: f.rangeHigh,
      type: 'forecast'
    });
  });

  return points;
}
