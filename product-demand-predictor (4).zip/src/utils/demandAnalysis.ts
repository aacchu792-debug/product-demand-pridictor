import { ProcessedDemandRecord } from '../types';

export function getCategoryDemandSummary(records: ProcessedDemandRecord[]) {
  const map = new Map<string, { totalDemand: number; count: number; totalPrice: number }>();

  records.forEach((r) => {
    const cat = r.product_category || 'Other';
    const entry = map.get(cat) || { totalDemand: 0, count: 0, totalPrice: 0 };
    entry.totalDemand += r.demand;
    entry.count += 1;
    entry.totalPrice += r.price;
    map.set(cat, entry);
  });

  return Array.from(map.entries()).map(([category, data]) => ({
    category,
    avgDemand: Math.round(data.totalDemand / (data.count || 1)),
    totalDemand: data.totalDemand,
    count: data.count,
    avgPrice: Math.round((data.totalPrice / (data.count || 1)) * 10) / 10
  })).sort((a, b) => b.avgDemand - a.avgDemand);
}

export function getSeasonalDemandSummary(records: ProcessedDemandRecord[]) {
  const map = new Map<string, { totalDemand: number; count: number }>();
  const seasonOrder = ['Spring', 'Summer', 'Autumn', 'Winter'];

  records.forEach((r) => {
    const season = r.season || 'Spring';
    const entry = map.get(season) || { totalDemand: 0, count: 0 };
    entry.totalDemand += r.demand;
    entry.count += 1;
    map.set(season, entry);
  });

  return seasonOrder
    .filter((s) => map.has(s))
    .map((season) => {
      const data = map.get(season)!;
      return {
        season,
        avgDemand: Math.round(data.totalDemand / (data.count || 1)),
        count: data.count,
        totalDemand: data.totalDemand
      };
    });
}

export function getPromotionDemandSummary(records: ProcessedDemandRecord[]) {
  let promoDemand = 0;
  let promoCount = 0;
  let nonPromoDemand = 0;
  let nonPromoCount = 0;

  records.forEach((r) => {
    if (r.promotion === 1) {
      promoDemand += r.demand;
      promoCount++;
    } else {
      nonPromoDemand += r.demand;
      nonPromoCount++;
    }
  });

  const avgPromo = promoCount > 0 ? Math.round(promoDemand / promoCount) : 0;
  const avgNonPromo = nonPromoCount > 0 ? Math.round(nonPromoDemand / nonPromoCount) : 0;
  const liftPct =
    avgNonPromo > 0 ? Math.round(((avgPromo - avgNonPromo) / avgNonPromo) * 1000) / 10 : 0;

  return [
    {
      group: 'Standard (No Promotion)',
      avgDemand: avgNonPromo,
      totalDemand: nonPromoDemand,
      count: nonPromoCount,
      promotion: 0
    },
    {
      group: 'Promotional Period',
      avgDemand: avgPromo,
      totalDemand: promoDemand,
      count: promoCount,
      promotion: 1,
      liftPct
    }
  ];
}

export function getProductDemandSummary(records: ProcessedDemandRecord[]) {
  const map = new Map<
    string,
    {
      productId: string;
      category: string;
      demands: number[];
      prices: number[];
      stocks: number[];
    }
  >();

  records.forEach((r) => {
    const entry = map.get(r.product_id) || {
      productId: r.product_id,
      category: r.product_category,
      demands: [],
      prices: [],
      stocks: []
    };
    entry.demands.push(r.demand);
    entry.prices.push(r.price);
    entry.stocks.push(r.stock_available);
    map.set(r.product_id, entry);
  });

  return Array.from(map.values()).map((p) => {
    const totalD = p.demands.reduce((a, b) => a + b, 0);
    const avgDemand = Math.round(totalD / p.demands.length);
    const maxDemand = Math.max(...p.demands);
    const minDemand = Math.min(...p.demands);
    const avgPrice = Math.round((p.prices.reduce((a, b) => a + b, 0) / p.prices.length) * 10) / 10;
    const avgStock = Math.round(p.stocks.reduce((a, b) => a + b, 0) / p.stocks.length);

    return {
      productId: p.productId,
      category: p.category,
      recordCount: p.demands.length,
      avgDemand,
      maxDemand,
      minDemand,
      avgPrice,
      avgStock
    };
  }).sort((a, b) => b.avgDemand - a.avgDemand);
}

export function getMonthlyDemandTrend(records: ProcessedDemandRecord[]) {
  const monthMap = new Map<string, { totalDemand: number; count: number; label: string }>();

  records.forEach((r) => {
    const key = `${r.year}-${String(r.month).padStart(2, '0')}`;
    const entry = monthMap.get(key) || {
      totalDemand: 0,
      count: 0,
      label: new Date(r.year, r.month - 1, 1).toLocaleDateString('en-US', {
        month: 'short',
        year: 'numeric'
      })
    };
    entry.totalDemand += r.demand;
    entry.count += 1;
    monthMap.set(key, entry);
  });

  return Array.from(monthMap.entries())
    .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
    .map(([key, val]) => ({
      key,
      date: val.label,
      avgDemand: Math.round(val.totalDemand / (val.count || 1)),
      totalDemand: val.totalDemand,
      recordCount: val.count
    }));
}

export function getScatterPriceDemand(records: ProcessedDemandRecord[], maxPoints = 200) {
  // Sample if records exceed maxPoints to keep chart fast and readable
  const step = Math.max(1, Math.floor(records.length / maxPoints));
  const result = [];
  for (let i = 0; i < records.length; i += step) {
    const r = records[i];
    result.push({
      price: r.price,
      demand: r.demand,
      productId: r.product_id,
      category: r.product_category,
      promotion: r.promotion ? 'Yes' : 'No'
    });
  }
  return result;
}

export function getScatterStockDemand(records: ProcessedDemandRecord[], maxPoints = 200) {
  const step = Math.max(1, Math.floor(records.length / maxPoints));
  const result = [];
  for (let i = 0; i < records.length; i += step) {
    const r = records[i];
    result.push({
      stock: r.stock_available,
      demand: r.demand,
      productId: r.product_id,
      category: r.product_category
    });
  }
  return result;
}

export function getScatterCustomerDemand(records: ProcessedDemandRecord[], maxPoints = 200) {
  const step = Math.max(1, Math.floor(records.length / maxPoints));
  const result = [];
  for (let i = 0; i < records.length; i += step) {
    const r = records[i];
    result.push({
      customers: r.customers,
      demand: r.demand,
      productId: r.product_id,
      category: r.product_category
    });
  }
  return result;
}
