import {
  DatasetStatistics,
  ModelComparisonResult,
  DynamicInsight,
  ProcessedDemandRecord
} from '../types';
import {
  getCategoryDemandSummary,
  getSeasonalDemandSummary,
  getPromotionDemandSummary
} from './demandAnalysis';

export function generateDynamicInsights(
  stats: DatasetStatistics,
  models: ModelComparisonResult,
  records: ProcessedDemandRecord[]
): DynamicInsight[] {
  const insights: DynamicInsight[] = [];

  // 1. Model comparison insight
  const rfRmse = models.randomForest.evaluation.rmse;
  const lrRmse = models.linearRegression.evaluation.rmse;
  const rfR2 = models.randomForest.evaluation.r2;
  const lrR2 = models.linearRegression.evaluation.r2;

  if (rfRmse < lrRmse) {
    const diffPct = Math.round(((lrRmse - rfRmse) / lrRmse) * 100);
    insights.push({
      id: 'ins-model-perf',
      type: 'model',
      category: 'Model Performance',
      title: 'Random Forest Outperformed Linear Regression',
      description: `Random Forest achieved ${diffPct}% lower RMSE (${rfRmse} units vs ${lrRmse} units) and an R² of ${rfR2}, capturing non-linear interactions across seasonality and promotions better than Linear Regression (R²: ${lrR2}).`,
      metric: `${diffPct}% Lower RMSE`
    });
  } else {
    insights.push({
      id: 'ins-model-perf',
      type: 'model',
      category: 'Model Performance',
      title: 'Linear Regression Demonstrates Robust Linear Fit',
      description: `Linear Regression achieved competitive generalization on chronological test records with an RMSE of ${lrRmse} units and an R² of ${lrR2}.`,
      metric: `RMSE: ${lrRmse}`
    });
  }

  // 2. Highest-demand category
  const catSummary = getCategoryDemandSummary(records);
  if (catSummary.length > 0) {
    const topCat = catSummary[0];
    const lowestCat = catSummary[catSummary.length - 1];
    insights.push({
      id: 'ins-top-category',
      type: 'positive',
      category: 'Category Demand',
      title: `Highest Demand Concentration in ${topCat.category}`,
      description: `The ${topCat.category} category logged the highest average demand of ${topCat.avgDemand} units across ${topCat.count} recorded dates, compared to ${lowestCat.avgDemand} units in ${lowestCat.category}.`,
      metric: `${topCat.avgDemand} avg units`
    });
  }

  // 3. Promotion lift
  const promoSummary = getPromotionDemandSummary(records);
  const promoItem = promoSummary.find((p) => p.promotion === 1);
  const stdItem = promoSummary.find((p) => p.promotion === 0);
  if (promoItem && stdItem && stdItem.avgDemand > 0) {
    const liftPct = Math.round(((promoItem.avgDemand - stdItem.avgDemand) / stdItem.avgDemand) * 100);
    insights.push({
      id: 'ins-promo-lift',
      type: liftPct > 0 ? 'positive' : 'neutral',
      category: 'Promotional Impact',
      title: liftPct > 0 ? `Promotions Boosted Demand by ${liftPct}%` : 'Moderate Promotional Elasticity',
      description: `Active promotional campaigns averaged ${promoItem.avgDemand} units per day, versus ${stdItem.avgDemand} units during non-promotional periods across the evaluated historical timeframe.`,
      metric: `+${liftPct}% Demand Lift`
    });
  }

  // 4. Strongest feature importance
  if (models.randomForest.featureImportances.length > 0) {
    const topFeat = models.randomForest.featureImportances[0];
    const secondFeat = models.randomForest.featureImportances[1];
    insights.push({
      id: 'ins-feature-importance',
      type: 'neutral',
      category: 'Feature Influence',
      title: `${topFeat.label} Is the Strongest Demand Predictor`,
      description: `In the trained Random Forest model, ${topFeat.label} accounted for ${topFeat.importance}% of total variance reduction, followed closely by ${secondFeat?.label || 'historical sales'} (${secondFeat?.importance || 0}%).`,
      metric: `${topFeat.importance}% Importance`
    });
  }

  // 5. Seasonal peak
  const seasonSummary = getSeasonalDemandSummary(records);
  if (seasonSummary.length > 0) {
    const sortedSeasons = [...seasonSummary].sort((a, b) => b.avgDemand - a.avgDemand);
    const topSeason = sortedSeasons[0];
    insights.push({
      id: 'ins-season-peak',
      type: 'neutral',
      category: 'Seasonality Pattern',
      title: `${topSeason.season} Peak Demand Volume`,
      description: `Average demand peaked during ${topSeason.season} at ${topSeason.avgDemand} units per observation, highlighting recurring temporal cyclicality in the product portfolio.`,
      metric: `${topSeason.avgDemand} units/day`
    });
  }

  return insights;
}
