import { ModelEvaluation } from '../types';

export function calculateMetrics(actuals: number[], predictions: number[]): ModelEvaluation {
  const n = actuals.length;
  if (n === 0) {
    return {
      mae: 0,
      mse: 0,
      rmse: 0,
      r2: 0,
      testActuals: [],
      testPredictions: [],
      residuals: [],
      meanResidual: 0,
      maxPositiveError: 0,
      maxNegativeError: 0,
      medianAbsoluteError: 0,
      errorDistribution: []
    };
  }

  let sumAbsErr = 0;
  let sumSqErr = 0;
  let sumActual = 0;
  const residuals: number[] = new Array(n);
  const absErrors: number[] = new Array(n);

  for (let i = 0; i < n; i++) {
    const act = actuals[i];
    const pred = predictions[i];
    const res = act - pred;
    residuals[i] = res;
    const absRes = Math.abs(res);
    absErrors[i] = absRes;
    sumAbsErr += absRes;
    sumSqErr += res * res;
    sumActual += act;
  }

  const meanActual = sumActual / n;
  let totalSumSquares = 0;
  for (let i = 0; i < n; i++) {
    const d = actuals[i] - meanActual;
    totalSumSquares += d * d;
  }

  const mae = Math.round((sumAbsErr / n) * 10) / 10;
  const mse = Math.round((sumSqErr / n) * 10) / 10;
  const rmse = Math.round(Math.sqrt(sumSqErr / n) * 10) / 10;

  // R² = 1 - (SS_res / SS_tot)
  const r2Raw = totalSumSquares > 0 ? 1 - sumSqErr / totalSumSquares : 0;
  const r2 = Math.round(Math.max(0, Math.min(1, r2Raw)) * 1000) / 1000;

  const meanResidual = Math.round((residuals.reduce((a, b) => a + b, 0) / n) * 10) / 10;
  const maxPositiveError = Math.round(Math.max(...residuals));
  const maxNegativeError = Math.round(Math.min(...residuals));

  // Median absolute error
  const sortedAbs = [...absErrors].sort((a, b) => a - b);
  const mid = Math.floor(n / 2);
  const medianAbsoluteError =
    n % 2 !== 0 ? sortedAbs[mid] : Math.round(((sortedAbs[mid - 1] + sortedAbs[mid]) / 2) * 10) / 10;

  // Error distribution histogram into 5 buckets
  const minErr = Math.min(...residuals);
  const maxErr = Math.max(...residuals);
  const span = Math.max(10, maxErr - minErr);
  const bucketCount = 6;
  const bucketWidth = span / bucketCount;

  const buckets: { range: string; count: number }[] = [];
  for (let b = 0; b < bucketCount; b++) {
    const bStart = Math.round(minErr + b * bucketWidth);
    const bEnd = Math.round(minErr + (b + 1) * bucketWidth);
    buckets.push({
      range: `${bStart > 0 ? '+' : ''}${bStart} to ${bEnd > 0 ? '+' : ''}${bEnd}`,
      count: 0
    });
  }

  residuals.forEach((res) => {
    let bIdx = Math.floor((res - minErr) / bucketWidth);
    if (bIdx >= bucketCount) bIdx = bucketCount - 1;
    if (bIdx < 0) bIdx = 0;
    buckets[bIdx].count++;
  });

  return {
    mae,
    mse,
    rmse,
    r2,
    testActuals: actuals,
    testPredictions: predictions,
    residuals,
    meanResidual,
    maxPositiveError,
    maxNegativeError,
    medianAbsoluteError,
    errorDistribution: buckets
  };
}
