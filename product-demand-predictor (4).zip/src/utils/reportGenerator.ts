import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import {
  DatasetStatistics,
  ModelComparisonResult,
  PredictionOutput,
  DynamicInsight,
  ProcessedDemandRecord
} from '../types';

export interface ReportData {
  stats: DatasetStatistics;
  models: ModelComparisonResult;
  prediction?: PredictionOutput | null;
  insights: DynamicInsight[];
  records: ProcessedDemandRecord[];
  chartElementId?: string;
}

export async function generatePdfReport(data: ReportData): Promise<void> {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 16;
    const contentWidth = pageWidth - margin * 2;
    let y = margin;

    // --- Header & Cover Banner ---
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(margin, y, contentWidth, 28, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('Product Demand Prediction Report', margin + 8, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184); // slate-400
    const genDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    doc.text(`Generated on: ${genDate} | In-Browser Machine Learning Analytics`, margin + 8, y + 20);

    y += 34;

    // --- Section 1: Executive Dataset Summary ---
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('1. Historical Dataset Summary', margin, y);
    y += 6;

    // Stats Grid
    const kpis = [
      { label: 'Total Historical Records', val: data.stats.totalRecords.toLocaleString() },
      { label: 'Unique Products Analyzed', val: data.stats.totalProducts.toString() },
      { label: 'Product Categories', val: data.stats.categoriesCount.toString() },
      { label: 'Overall Average Demand', val: `${data.stats.avgDemand.toLocaleString()} units` },
      { label: 'Average Product Price', val: `$${data.stats.avgPrice.toFixed(2)}` },
      { label: 'Average Stock Level', val: `${data.stats.avgStock.toLocaleString()} units` }
    ];

    const boxWidth = (contentWidth - 6) / 3;
    const boxHeight = 14;
    kpis.forEach((kpi, idx) => {
      const col = idx % 3;
      const row = Math.floor(idx / 3);
      const bx = margin + col * (boxWidth + 3);
      const by = y + row * (boxHeight + 3);

      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(bx, by, boxWidth, boxHeight, 2, 2, 'FD');

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(kpi.label, bx + 4, by + 5);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(kpi.val, bx + 4, by + 11);
    });

    y += 2 * (boxHeight + 3) + 6;

    // --- Section 2: Demand Prediction Scenario ---
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('2. Demand Prediction Scenario', margin, y);
    y += 6;

    if (data.prediction) {
      const p = data.prediction;
      doc.setFillColor(241, 245, 249);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(margin, y, contentWidth, 34, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(15, 23, 42);
      doc.text(`Expected Demand: ${p.predictedDemand.toLocaleString()} units`, margin + 6, y + 9);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      doc.text(
        `Estimated Model Range: ${p.rangeLow.toLocaleString()} – ${p.rangeHigh.toLocaleString()} units (±1.65 RMSE)`,
        margin + 6,
        y + 16
      );
      doc.text(`Demand Classification: ${p.interpretation} | Confidence Score: ${p.confidenceScore}%`, margin + 6, y + 22);
      doc.text(
        `Scenario Product: ${p.input.productId} (${p.input.productCategory}) | Date: ${p.input.predictionDate} | Model: ${p.modelUsed}`,
        margin + 6,
        y + 28
      );

      y += 40;
    } else {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text('No active single prediction was generated yet. Showing baseline models.', margin, y);
      y += 8;
    }

    // --- Section 3: Machine Learning Model Performance ---
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('3. Machine Learning Model Comparison (80/20 Chronological Split)', margin, y);
    y += 6;

    // Model comparison table
    const lr = data.models.linearRegression.evaluation;
    const rf = data.models.randomForest.evaluation;

    // Header row
    doc.setFillColor(30, 41, 59);
    doc.rect(margin, y, contentWidth, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text('Metric', margin + 4, y + 4.8);
    doc.text('Linear Regression (Baseline)', margin + 55, y + 4.8);
    doc.text('Random Forest Regression (Ensemble)', margin + 115, y + 4.8);
    y += 7;

    const metricsRows = [
      ['MAE (Mean Absolute Error)', `${lr.mae} units`, `${rf.mae} units`],
      ['MSE (Mean Squared Error)', `${lr.mse}`, `${rf.mse}`],
      ['RMSE (Root Mean Squared Error)', `${lr.rmse} units`, `${rf.rmse} units`],
      ['R² (Explained Variance Score)', `${lr.r2}`, `${rf.r2}`],
      ['Evaluation Split Records', `${data.models.trainSize} Train / ${data.models.testSize} Test`, `${data.models.trainSize} Train / ${data.models.testSize} Test`],
      ['Selected Optimal Model', data.models.bestModel === 'Linear Regression' ? 'WINNER' : 'Baseline', data.models.bestModel === 'Random Forest' ? 'WINNER' : 'Ensemble']
    ];

    metricsRows.forEach((row, i) => {
      doc.setFillColor(i % 2 === 0 ? 255 : 248, 250, 252);
      doc.rect(margin, y, contentWidth, 6, 'F');
      doc.setTextColor(51, 65, 85);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(row[0], margin + 4, y + 4.2);
      doc.text(row[1], margin + 55, y + 4.2);
      doc.text(row[2], margin + 115, y + 4.2);
      y += 6;
    });

    y += 6;

    // --- Section 4: Dynamic Insights ---
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('4. Key Analytical Insights', margin, y);
    y += 6;

    data.insights.slice(0, 4).forEach((ins) => {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(30, 41, 59);
      doc.text(`• ${ins.title}`, margin + 2, y);
      y += 4.2;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      const splitText = doc.splitTextToSize(ins.description, contentWidth - 6);
      doc.text(splitText, margin + 5, y);
      y += splitText.length * 3.8 + 2;
    });

    // Check if we can capture chart visual
    if (data.chartElementId) {
      const el = document.getElementById(data.chartElementId);
      if (el) {
        try {
          const canvas = await html2canvas(el, { scale: 1.5, useCORS: true, logging: false });
          const imgData = canvas.toDataURL('image/png');
          if (y > 210) {
            doc.addPage();
            y = margin;
          }
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(11);
          doc.setTextColor(15, 23, 42);
          doc.text('Captured Visualization', margin, y);
          y += 4;
          const imgHeight = (canvas.height * (contentWidth * 0.9)) / canvas.width;
          doc.addImage(imgData, 'PNG', margin, y, contentWidth * 0.9, Math.min(65, imgHeight));
          y += Math.min(65, imgHeight) + 6;
        } catch (e) {
          console.warn('Chart capture skipped in PDF:', e);
        }
      }
    }

    // --- Mandatory Disclaimer ---
    const disclaimer =
      'Disclaimer: This application provides machine-learning estimates based on historical data. Predictions are not guaranteed future demand values and should not be treated as professional inventory, financial, or business advice.';

    // Bottom placement
    const pageHeight = doc.internal.pageSize.getHeight();
    const discY = Math.max(y + 4, pageHeight - 20);

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    const discLines = doc.splitTextToSize(disclaimer, contentWidth);
    doc.text(discLines, margin, discY);

    // Save locally
    const filename = `Product_Demand_Report_${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(filename);
  } catch (error) {
    console.error('PDF Generation failed:', error);
    throw new Error('Unable to generate the report. Please try again.');
  }
}
