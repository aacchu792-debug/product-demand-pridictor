import {
  PredictionInput,
  PredictionOutput,
  ModelComparisonResult,
  DatasetStatistics,
  ProcessedDemandRecord
} from '../types';
import { extractDateFeatures } from '../ml/dateFeatures';
import { encodeFeatureRow } from '../ml/encoding';

export function runPrediction(
  input: PredictionInput,
  models: ModelComparisonResult,
  stats: DatasetStatistics,
  records: ProcessedDemandRecord[]
): PredictionOutput {
  const parsedDate = new Date(input.predictionDate || new Date().toISOString().split('T')[0]);
  const dateFeats = extractDateFeatures(parsedDate);

  // Derive historical lag / rolling context for this product if available
  const productRecords = records.filter((r) => r.product_id === input.productId);
  let lag1 = input.previousDemand;
  let lag7 = input.previousDemand;
  let rolling7 = input.previousDemand;

  if (productRecords.length > 0) {
    const recent = productRecords[productRecords.length - 1];
    lag1 = recent.demand || input.previousDemand;
    const lastFew = productRecords.slice(-7).map((r) => r.demand);
    rolling7 = Math.round(lastFew.reduce((a, b) => a + b, 0) / (lastFew.length || 1));
    if (productRecords.length >= 7) {
      lag7 = productRecords[productRecords.length - 7].demand;
    }
  }

  const stockToDemandRatio =
    input.previousDemand > 0
      ? Math.round((input.stockAvailable / input.previousDemand) * 100) / 100
      : 1.0;

  // Encode row
  const featureRow = encodeFeatureRow(
    {
      price: input.price,
      previous_sales: input.previousSales,
      previous_demand: input.previousDemand,
      stock_available: input.stockAvailable,
      customers: input.expectedCustomers,
      promotion: input.promotion,
      holiday: input.holiday,
      month: dateFeats.month,
      dayOfWeek: dateFeats.dayOfWeek,
      quarter: dateFeats.quarter,
      isWeekend: dateFeats.isWeekend,
      lag_1_demand: lag1,
      lag_7_demand: lag7,
      rolling_7_day_demand: rolling7,
      stockToDemandRatio,
      product_category: input.productCategory,
      season: input.season
    },
    {
      categories: models.categories,
      seasons: models.seasons
    }
  );

  const selectedModel = input.modelType === 'linearRegression' ? models.linearRegression : models.randomForest;
  const rawPred = selectedModel.predict(featureRow);
  const predictedDemand = Math.max(5, Math.round(rawPred));

  // Derive estimated range from model test-set RMSE (90% interval approx: ±1.645 * RMSE)
  const rmse = selectedModel.evaluation.rmse || 25;
  const margin = Math.round(rmse * 1.645);
  const rangeLow = Math.max(0, predictedDemand - margin);
  const rangeHigh = predictedDemand + margin;

  // Dynamic interpretation based on dataset quantiles
  const { q20, q40, q60, q80 } = stats.demandQuantiles;
  let interpretation: PredictionOutput['interpretation'] = 'Average Demand';
  let interpretationColor = 'text-amber-600 bg-amber-50 border-amber-200';

  if (predictedDemand < q20) {
    interpretation = 'Very Low Demand';
    interpretationColor = 'text-slate-600 bg-slate-100 border-slate-300';
  } else if (predictedDemand < q40) {
    interpretation = 'Low Demand';
    interpretationColor = 'text-blue-600 bg-blue-50 border-blue-200';
  } else if (predictedDemand <= q60) {
    interpretation = 'Average Demand';
    interpretationColor = 'text-emerald-600 bg-emerald-50 border-emerald-200';
  } else if (predictedDemand <= q80) {
    interpretation = 'High Demand';
    interpretationColor = 'text-purple-600 bg-purple-50 border-purple-200';
  } else {
    interpretation = 'Very High Demand';
    interpretationColor = 'text-rose-600 bg-rose-50 border-rose-200';
  }

  // Model test R2 as a proxy for empirical confidence score
  const r2Score = Math.max(0.7, Math.min(0.98, selectedModel.evaluation.r2 || 0.85));
  const confidenceScore = Math.round(r2Score * 100);

  return {
    predictedDemand,
    rangeLow,
    rangeHigh,
    interpretation,
    interpretationColor,
    modelUsed: input.modelType === 'linearRegression' ? 'Linear Regression' : 'Random Forest Regression',
    confidenceScore,
    input,
    timestamp: new Date().toLocaleTimeString()
  };
}
