import Papa from 'papaparse';

export async function fetchDefaultDataset(): Promise<any[]> {
  const possiblePaths = ['/data/product_demand.csv', '/product_demand.csv'];

  for (const path of possiblePaths) {
    try {
      const response = await fetch(path);
      if (response.ok) {
        const csvText = await response.text();
        return parseCsvString(csvText);
      }
    } catch (e) {
      console.warn(`Failed to fetch dataset from ${path}:`, e);
    }
  }

  throw new Error('Could not load product_demand.csv from public directory.');
}

export function parseCsvString(csvText: string): Promise<any[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      complete: (results) => {
        if (results.errors && results.errors.length > 0) {
          console.warn('PapaParse warnings:', results.errors);
        }
        if (!results.data || results.data.length === 0) {
          reject(new Error('CSV file is empty or could not be parsed.'));
        } else {
          resolve(results.data);
        }
      },
      error: (err) => {
        reject(err);
      }
    });
  });
}
