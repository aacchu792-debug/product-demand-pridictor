export interface RawDemandRecord {
  demand_id: string;
  date: string;
  product_id: string;
  product_category: string;
  price: number;
  previous_sales: number;
  stock_available: number;
  promotion: number;
  holiday: number;
  customers: number;
  season: string;
  previous_demand: number;
  demand: number;
}

export interface ProcessedDemandRecord extends RawDemandRecord {
  parsedDate: Date;
  year: number;
  month: number;
  day: number;
  dayOfWeek: number;
  weekOfYear: number;
  quarter: number;
  isWeekend: number;
  lag_1_demand: number;
  lag_7_demand: number;
  lag_30_demand: number;
  rolling_7_day_demand: number;
  rolling_30_day_demand: number;
  stockToDemandRatio: number;
  priceCategory: 'Low Price' | 'Medium Price' | 'High Price';
}

export interface DatasetStatistics {
  totalRecords: number;
  totalProducts: number;
  categoriesCount: number;
  categoriesList: string[];
  productsList: { id: string; name?: string; category: string }[];
  avgDemand: number;
  maxDemand: number;
  minDemand: number;
  avgPrice: number;
  avgStock: number;
  demandQuantiles: {
    q20: number;
    q40: number;
    q60: number;
    q80: number;
  };
  priceQuantiles: {
    lowMax: number;
    mediumMax: number;
  };
}

export interface ModelEvaluation {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
  testActuals: number[];
  testPredictions: number[];
  residuals: number[];
  meanResidual: number;
  maxPositiveError: number;
  maxNegativeError: number;
  medianAbsoluteError: number;
  errorDistribution: { range: string; count: number }[];
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number;
  label: string;
}

export interface CoefficientItem {
  feature: string;
  coefficient: number;
  normalizedImportance: number;
  label: string;
}

export interface TrainedModelResult {
  evaluation: ModelEvaluation;
  featureNames: string[];
}

export interface LinearRegressionResult extends TrainedModelResult {
  weights: number[];
  bias: number;
  featureMeans: number[];
  featureStds: number[];
  coefficients: CoefficientItem[];
  predict: (features: number[]) => number;
}

export interface RandomForestResult extends TrainedModelResult {
  featureImportances: FeatureImportanceItem[];
  treeCount: number;
  predict: (features: number[]) => number;
}

export interface ModelComparisonResult {
  linearRegression: LinearRegressionResult;
  randomForest: RandomForestResult;
  bestModel: 'Linear Regression' | 'Random Forest';
  trainSize: number;
  testSize: number;
  featureNames: string[];
  categories: string[];
  seasons: string[];
}

export interface PredictionInput {
  productId: string;
  productCategory: string;
  price: number;
  previousSales: number;
  previousDemand: number;
  stockAvailable: number;
  expectedCustomers: number;
  promotion: number;
  holiday: number;
  season: string;
  predictionDate: string;
  modelType: 'randomForest' | 'linearRegression';
}

export interface PredictionOutput {
  predictedDemand: number;
  rangeLow: number;
  rangeHigh: number;
  interpretation: 'Very Low Demand' | 'Low Demand' | 'Average Demand' | 'High Demand' | 'Very High Demand';
  interpretationColor: string;
  modelUsed: string;
  confidenceScore: number;
  input: PredictionInput;
  timestamp: string;
}

export interface ForecastItem {
  date: string;
  dayLabel: string;
  predictedDemand: number;
  rangeLow: number;
  rangeHigh: number;
  customersEst: number;
  promotion: number;
  holiday: number;
  isWeekend: boolean;
}

export interface DynamicInsight {
  id: string;
  type: 'positive' | 'warning' | 'neutral' | 'model';
  category: string;
  title: string;
  description: string;
  metric?: string;
}
