import { CoefficientItem, ModelEvaluation } from '../types';

/**
 * Multiple Linear Regression with Ridge Regularization & Feature Standardization.
 * Solves (Z^T Z + λ I) w = Z^T y via Gaussian elimination with partial pivoting.
 */
export class LinearRegressionModel {
  public weights: number[] = [];
  public bias: number = 0;
  public featureMeans: number[] = [];
  public featureStds: number[] = [];
  public standardizedWeights: number[] = [];
  public featureNames: string[] = [];
  public isTrained: boolean = false;

  constructor(public lambda: number = 0.01) {}

  public train(X: number[][], y: number[], featureNames: string[]): void {
    const numSamples = X.length;
    if (numSamples === 0) throw new Error('Cannot train on empty dataset');
    const numFeatures = X[0].length;
    this.featureNames = featureNames;

    // 1. Calculate means and standard deviations for each feature
    this.featureMeans = new Array(numFeatures).fill(0);
    this.featureStds = new Array(numFeatures).fill(0);

    for (let j = 0; j < numFeatures; j++) {
      let sum = 0;
      for (let i = 0; i < numSamples; i++) {
        sum += X[i][j];
      }
      this.featureMeans[j] = sum / numSamples;

      let varSum = 0;
      for (let i = 0; i < numSamples; i++) {
        const diff = X[i][j] - this.featureMeans[j];
        varSum += diff * diff;
      }
      const std = Math.sqrt(varSum / numSamples);
      this.featureStds[j] = std > 1e-7 ? std : 1.0;
    }

    // 2. Standardize X
    const Z: number[][] = [];
    for (let i = 0; i < numSamples; i++) {
      const zRow = new Array(numFeatures);
      for (let j = 0; j < numFeatures; j++) {
        zRow[j] = (X[i][j] - this.featureMeans[j]) / this.featureStds[j];
      }
      Z.push(zRow);
    }

    // 3. Center y
    let ySum = 0;
    for (let i = 0; i < numSamples; i++) ySum += y[i];
    const yMean = ySum / numSamples;
    const yCentered = y.map((val) => val - yMean);

    // 4. Compute A = Z^T * Z + lambda * I, and bVec = Z^T * yCentered
    const A: number[][] = Array.from({ length: numFeatures }, () => new Array(numFeatures).fill(0));
    const bVec: number[] = new Array(numFeatures).fill(0);

    for (let i = 0; i < numSamples; i++) {
      const zRow = Z[i];
      const yVal = yCentered[i];
      for (let j = 0; j < numFeatures; j++) {
        bVec[j] += zRow[j] * yVal;
        for (let k = j; k < numFeatures; k++) {
          A[j][k] += zRow[j] * zRow[k];
        }
      }
    }

    // Mirror upper triangle and add ridge regularizer
    for (let j = 0; j < numFeatures; j++) {
      A[j][j] += this.lambda * numSamples;
      for (let k = j + 1; k < numFeatures; k++) {
        A[k][j] = A[j][k];
      }
    }

    // 5. Solve linear system A * w_std = bVec via Gaussian Elimination
    this.standardizedWeights = solveLinearSystem(A, bVec);

    // 6. Recover unstandardized weights and bias
    this.weights = new Array(numFeatures);
    let biasAdjustment = 0;
    for (let j = 0; j < numFeatures; j++) {
      this.weights[j] = this.standardizedWeights[j] / this.featureStds[j];
      biasAdjustment += this.weights[j] * this.featureMeans[j];
    }
    this.bias = yMean - biasAdjustment;
    this.isTrained = true;
  }

  public predict(features: number[]): number {
    if (!this.isTrained) throw new Error('Linear regression model has not been trained yet');
    let pred = this.bias;
    const len = Math.min(features.length, this.weights.length);
    for (let j = 0; j < len; j++) {
      pred += features[j] * this.weights[j];
    }
    return Math.max(0, Math.round(pred));
  }

  public getCoefficients(): CoefficientItem[] {
    const totalAbs = this.standardizedWeights.reduce((acc, w) => acc + Math.abs(w), 0) || 1;
    return this.featureNames.map((name, idx) => {
      const coef = this.weights[idx] ?? 0;
      const stdCoef = this.standardizedWeights[idx] ?? 0;
      const normImportance = Math.round((Math.abs(stdCoef) / totalAbs) * 1000) / 10;
      return {
        feature: name,
        coefficient: Math.round(coef * 1000) / 1000,
        normalizedImportance: normImportance,
        label: formatFeatureLabel(name)
      };
    }).sort((a, b) => b.normalizedImportance - a.normalizedImportance);
  }
}

function solveLinearSystem(A: number[][], b: number[]): number[] {
  const n = A.length;
  // Augmented matrix
  const M: number[][] = Array.from({ length: n }, (_, i) => [...A[i], b[i]]);

  for (let i = 0; i < n; i++) {
    // Partial pivoting
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(M[k][i]) > Math.abs(M[maxRow][i])) {
        maxRow = k;
      }
    }
    const temp = M[i];
    M[i] = M[maxRow];
    M[maxRow] = temp;

    if (Math.abs(M[i][i]) < 1e-12) {
      M[i][i] = 1e-12; // Numerical safety
    }

    for (let k = i + 1; k < n; k++) {
      const factor = M[k][i] / M[i][i];
      for (let j = i; j <= n; j++) {
        M[k][j] -= factor * M[i][j];
      }
    }
  }

  // Back substitution
  const x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let sum = M[i][n];
    for (let j = i + 1; j < n; j++) {
      sum -= M[i][j] * x[j];
    }
    x[i] = sum / M[i][i];
  }

  return x;
}

export function formatFeatureLabel(featureName: string): string {
  if (featureName.startsWith('cat_')) {
    const raw = featureName.replace('cat_', '').replace(/_/g, ' ');
    return `Category: ${raw.charAt(0).toUpperCase() + raw.slice(1)}`;
  }
  if (featureName.startsWith('season_')) {
    const raw = featureName.replace('season_', '');
    return `Season: ${raw.charAt(0).toUpperCase() + raw.slice(1)}`;
  }
  const mapping: Record<string, string> = {
    price: 'Price ($)',
    previous_sales: 'Previous Sales',
    previous_demand: 'Previous Demand',
    stock_available: 'Stock Available',
    customers: 'Customer Activity',
    promotion: 'Promotion Active',
    holiday: 'Holiday Active',
    month: 'Month of Year',
    dayOfWeek: 'Day of Week',
    quarter: 'Fiscal Quarter',
    isWeekend: 'Weekend Flag',
    lag_1_demand: 'Lag 1-Day Demand',
    lag_7_demand: 'Lag 7-Day Demand',
    rolling_7_day_demand: 'Rolling 7-Day Avg Demand',
    stockToDemandRatio: 'Stock-to-Demand Ratio'
  };
  return mapping[featureName] || featureName.replace(/_/g, ' ');
}
