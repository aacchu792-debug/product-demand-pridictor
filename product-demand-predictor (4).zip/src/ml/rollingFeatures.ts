export interface RollingResult {
  rolling_7_day_demand: number;
  rolling_30_day_demand: number;
}

/**
 * Computes moving averages of demand over strictly prior observations for the product.
 * Guarantees zero target leakage into the current observation.
 */
export function computeRollingFeatures<T extends { product_id: string; demand: number; previous_demand: number }>(
  records: T[],
  currentIndex: number
): RollingResult {
  const currentRecord = records[currentIndex];
  const productId = currentRecord.product_id;

  const priorDemands: number[] = [];
  for (let i = currentIndex - 1; i >= 0; i--) {
    if (records[i].product_id === productId) {
      priorDemands.push(records[i].demand);
      if (priorDemands.length >= 30) break;
    }
  }

  const defaultDemand = currentRecord.previous_demand || currentRecord.demand || 100;

  if (priorDemands.length === 0) {
    return {
      rolling_7_day_demand: defaultDemand,
      rolling_30_day_demand: defaultDemand
    };
  }

  const window7 = priorDemands.slice(0, 7);
  const sum7 = window7.reduce((acc, v) => acc + v, 0);
  const rolling_7_day_demand = Math.round(sum7 / window7.length);

  const window30 = priorDemands.slice(0, 30);
  const sum30 = window30.reduce((acc, v) => acc + v, 0);
  const rolling_30_day_demand = Math.round(sum30 / window30.length);

  return {
    rolling_7_day_demand,
    rolling_30_day_demand
  };
}
