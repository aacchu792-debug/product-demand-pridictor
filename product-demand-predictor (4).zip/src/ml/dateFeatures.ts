export interface DateFeatures {
  year: number;
  month: number;
  day: number;
  dayOfWeek: number;
  weekOfYear: number;
  quarter: number;
  isWeekend: number;
}

export function extractDateFeatures(dateInput: string | Date): DateFeatures {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1-12
  const day = d.getDate();
  const dayOfWeek = d.getDay(); // 0 (Sun) - 6 (Sat)
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6 ? 1 : 0;
  const quarter = Math.floor((d.getMonth() + 3) / 3);

  // Week of year calculation
  const startOfYear = new Date(d.getFullYear(), 0, 1);
  const diffTime = d.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diffTime / (24 * 60 * 60 * 1000));
  const weekOfYear = Math.min(52, Math.max(1, Math.ceil((dayOfYear + startOfYear.getDay() + 1) / 7)));

  return {
    year,
    month,
    day,
    dayOfWeek,
    weekOfYear,
    quarter,
    isWeekend
  };
}
