import { RawDemandRecord, ProcessedDemandRecord, DatasetStatistics } from '../types';
import { extractDateFeatures } from './dateFeatures';
import { computeLagFeatures } from './lagFeatures';
import { computeRollingFeatures } from './rollingFeatures';

export function preprocessDataset(rawRecords: any[]): {
  records: ProcessedDemandRecord[];
  stats: DatasetStatistics;
} {
  if (!rawRecords || rawRecords.length === 0) {
    throw new Error('Dataset is empty or failed to load.');
  }

  // 1. Initial Cleaning & Type Validation
  const validRecords: RawDemandRecord[] = [];
  const seenIds = new Set<string>();

  // Collect numbers for median imputation
  const priceVals: number[] = [];
  const salesVals: number[] = [];
  const stockVals: number[] = [];
  const custVals: number[] = [];
  const prevDemandVals: number[] = [];
  const demandVals: number[] = [];

  rawRecords.forEach((r, idx) => {
    const demandId = r.demand_id ? String(r.demand_id).trim() : `DEM-${idx + 1}`;
    if (seenIds.has(demandId)) return; // Deduplicate
    seenIds.add(demandId);

    const dateStr = r.date ? String(r.date).trim() : '';
    if (!dateStr || isNaN(Date.parse(dateStr))) return; // Skip invalid dates

    const price = parseFloat(r.price);
    const prevSales = parseFloat(r.previous_sales);
    const stock = parseFloat(r.stock_available);
    const promo = r.promotion === '1' || r.promotion === 1 || String(r.promotion).toLowerCase() === 'yes' ? 1 : 0;
    const holiday = r.holiday === '1' || r.holiday === 1 || String(r.holiday).toLowerCase() === 'yes' ? 1 : 0;
    const cust = parseFloat(r.customers);
    const prevDemand = parseFloat(r.previous_demand);
    const demand = parseFloat(r.demand);

    if (!isNaN(price)) priceVals.push(price);
    if (!isNaN(prevSales)) salesVals.push(prevSales);
    if (!isNaN(stock)) stockVals.push(stock);
    if (!isNaN(cust)) custVals.push(cust);
    if (!isNaN(prevDemand)) prevDemandVals.push(prevDemand);
    if (!isNaN(demand)) demandVals.push(demand);

    validRecords.push({
      demand_id: demandId,
      date: dateStr,
      product_id: r.product_id ? String(r.product_id).trim() : 'PROD-01',
      product_category: r.product_category ? String(r.product_category).trim() : 'General',
      price: !isNaN(price) ? price : 0,
      previous_sales: !isNaN(prevSales) ? prevSales : 0,
      stock_available: !isNaN(stock) ? stock : 0,
      promotion: promo,
      holiday: holiday,
      customers: !isNaN(cust) ? cust : 0,
      season: r.season ? String(r.season).trim() : 'Spring',
      previous_demand: !isNaN(prevDemand) ? prevDemand : 0,
      demand: !isNaN(demand) ? demand : 0
    });
  });

  // Calculate medians for imputation
  const medianPrice = getMedian(priceVals, 50);
  const medianSales = getMedian(salesVals, 100);
  const medianStock = getMedian(stockVals, 150);
  const medianCust = getMedian(custVals, 300);
  const medianPrevDemand = getMedian(prevDemandVals, 100);
  const medianDemand = getMedian(demandVals, 120);

  // Apply imputation
  validRecords.forEach((r) => {
    if (r.price <= 0) r.price = medianPrice;
    if (r.previous_sales <= 0) r.previous_sales = medianSales;
    if (r.stock_available <= 0) r.stock_available = medianStock;
    if (r.customers <= 0) r.customers = medianCust;
    if (r.previous_demand <= 0) r.previous_demand = medianPrevDemand;
    if (r.demand <= 0) r.demand = medianDemand;
  });

  // 2. Sort chronologically
  validRecords.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // 3. Compute Price Quantiles for derived business feature
  const sortedPrices = validRecords.map((r) => r.price).sort((a, b) => a - b);
  const p33 = sortedPrices[Math.floor(sortedPrices.length * 0.33)] || 50;
  const p66 = sortedPrices[Math.floor(sortedPrices.length * 0.66)] || 120;

  // 4. Feature Engineering
  const processedRecords: ProcessedDemandRecord[] = [];

  for (let i = 0; i < validRecords.length; i++) {
    const raw = validRecords[i];
    const parsedDate = new Date(raw.date);
    const dateFeats = extractDateFeatures(parsedDate);
    const lagFeats = computeLagFeatures(validRecords, i);
    const rollingFeats = computeRollingFeatures(validRecords, i);

    const stockToDemandRatio =
      raw.previous_demand > 0 ? Math.round((raw.stock_available / raw.previous_demand) * 100) / 100 : 1.0;

    let priceCategory: 'Low Price' | 'Medium Price' | 'High Price' = 'Medium Price';
    if (raw.price <= p33) {
      priceCategory = 'Low Price';
    } else if (raw.price > p66) {
      priceCategory = 'High Price';
    }

    processedRecords.push({
      ...raw,
      parsedDate,
      ...dateFeats,
      ...lagFeats,
      ...rollingFeats,
      stockToDemandRatio,
      priceCategory
    });
  }

  // 5. Compute Dataset Statistics
  const totalRecords = processedRecords.length;
  const productSet = new Set<string>();
  const categorySet = new Set<string>();
  const productCategoryMap = new Map<string, string>();

  let sumDemand = 0;
  let maxDemand = -Infinity;
  let minDemand = Infinity;
  let sumPrice = 0;
  let sumStock = 0;

  processedRecords.forEach((r) => {
    productSet.add(r.product_id);
    categorySet.add(r.product_category);
    productCategoryMap.set(r.product_id, r.product_category);

    sumDemand += r.demand;
    if (r.demand > maxDemand) maxDemand = r.demand;
    if (r.demand < minDemand) minDemand = r.demand;
    sumPrice += r.price;
    sumStock += r.stock_available;
  });

  const sortedDemands = processedRecords.map((r) => r.demand).sort((a, b) => a - b);
  const q20 = sortedDemands[Math.floor(totalRecords * 0.2)] || 50;
  const q40 = sortedDemands[Math.floor(totalRecords * 0.4)] || 100;
  const q60 = sortedDemands[Math.floor(totalRecords * 0.6)] || 180;
  const q80 = sortedDemands[Math.floor(totalRecords * 0.8)] || 300;

  const productsList = Array.from(productSet).sort().map((id) => ({
    id,
    category: productCategoryMap.get(id) || 'General'
  }));

  const stats: DatasetStatistics = {
    totalRecords,
    totalProducts: productSet.size,
    categoriesCount: categorySet.size,
    categoriesList: Array.from(categorySet).sort(),
    productsList,
    avgDemand: Math.round(sumDemand / (totalRecords || 1)),
    maxDemand: maxDemand !== -Infinity ? maxDemand : 0,
    minDemand: minDemand !== Infinity ? minDemand : 0,
    avgPrice: Math.round((sumPrice / (totalRecords || 1)) * 10) / 10,
    avgStock: Math.round(sumStock / (totalRecords || 1)),
    demandQuantiles: { q20, q40, q60, q80 },
    priceQuantiles: { lowMax: p33, mediumMax: p66 }
  };

  return { records: processedRecords, stats };
}

function getMedian(values: number[], fallback: number): number {
  if (!values || values.length === 0) return fallback;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 !== 0 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}
