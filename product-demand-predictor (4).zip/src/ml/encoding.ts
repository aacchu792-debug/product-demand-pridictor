export interface CategoricalMetadata {
  categories: string[];
  seasons: string[];
}

export function buildCategoricalMetadata(
  records: { product_category: string; season: string }[]
): CategoricalMetadata {
  const catSet = new Set<string>();
  const seasonSet = new Set<string>();

  records.forEach((r) => {
    if (r.product_category) catSet.add(r.product_category.trim());
    if (r.season) seasonSet.add(r.season.trim());
  });

  const defaultCategories = ['Electronics', 'Home & Living', 'Apparel', 'Sports & Fitness', 'Groceries'];
  const defaultSeasons = ['Spring', 'Summer', 'Autumn', 'Winter'];

  defaultCategories.forEach((c) => catSet.add(c));
  defaultSeasons.forEach((s) => seasonSet.add(s));

  return {
    categories: Array.from(catSet).sort(),
    seasons: Array.from(seasonSet).sort()
  };
}

export function getFeatureColumnNames(metadata: CategoricalMetadata): string[] {
  const numericalFeatures = [
    'price',
    'previous_sales',
    'previous_demand',
    'stock_available',
    'customers',
    'promotion',
    'holiday',
    'month',
    'dayOfWeek',
    'quarter',
    'isWeekend',
    'lag_1_demand',
    'lag_7_demand',
    'rolling_7_day_demand',
    'stockToDemandRatio'
  ];

  const categoryFeatures = metadata.categories.map((c) => `cat_${c.toLowerCase().replace(/[^a-z0-9]/g, '_')}`);
  const seasonFeatures = metadata.seasons.map((s) => `season_${s.toLowerCase()}`);

  return [...numericalFeatures, ...categoryFeatures, ...seasonFeatures];
}

export function encodeFeatureRow(
  input: {
    price: number;
    previous_sales: number;
    previous_demand: number;
    stock_available: number;
    customers: number;
    promotion: number;
    holiday: number;
    month: number;
    dayOfWeek: number;
    quarter: number;
    isWeekend: number;
    lag_1_demand: number;
    lag_7_demand: number;
    rolling_7_day_demand: number;
    stockToDemandRatio: number;
    product_category: string;
    season: string;
  },
  metadata: CategoricalMetadata
): number[] {
  const row: number[] = [
    input.price,
    input.previous_sales,
    input.previous_demand,
    input.stock_available,
    input.customers,
    input.promotion ? 1 : 0,
    input.holiday ? 1 : 0,
    input.month,
    input.dayOfWeek,
    input.quarter,
    input.isWeekend ? 1 : 0,
    input.lag_1_demand,
    input.lag_7_demand,
    input.rolling_7_day_demand,
    input.stockToDemandRatio
  ];

  // One-hot categories
  metadata.categories.forEach((cat) => {
    row.push(input.product_category?.toLowerCase() === cat.toLowerCase() ? 1 : 0);
  });

  // One-hot seasons
  metadata.seasons.forEach((season) => {
    row.push(input.season?.toLowerCase() === season.toLowerCase() ? 1 : 0);
  });

  return row;
}
