import { FeatureImportanceItem } from '../types';
import { formatFeatureLabel } from './linearRegression';

interface TreeNode {
  isLeaf: boolean;
  value: number;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

class RegressionTree {
  public root: TreeNode | null = null;
  public featureImportances: number[];

  constructor(
    public maxDepth: number = 7,
    public minSamplesSplit: number = 5,
    public minSamplesLeaf: number = 2,
    public maxFeatures: number = 6
  ) {
    this.featureImportances = [];
  }

  public train(X: number[][], y: number[]): void {
    const numFeatures = X[0].length;
    this.featureImportances = new Array(numFeatures).fill(0);
    const indices = Array.from({ length: X.length }, (_, i) => i);
    this.root = this.buildNode(X, y, indices, 0);
  }

  private buildNode(X: number[][], y: number[], indices: number[], depth: number): TreeNode {
    const n = indices.length;
    let sumY = 0;
    for (let i = 0; i < n; i++) sumY += y[indices[i]];
    const meanY = sumY / n;

    if (depth >= this.maxDepth || n < this.minSamplesSplit) {
      return { isLeaf: true, value: meanY };
    }

    // Node total variance
    let nodeVar = 0;
    for (let i = 0; i < n; i++) {
      const diff = y[indices[i]] - meanY;
      nodeVar += diff * diff;
    }

    if (nodeVar < 1e-6) {
      return { isLeaf: true, value: meanY };
    }

    const numFeatures = X[0].length;
    // Subsample features
    const allFeatureIndices = Array.from({ length: numFeatures }, (_, i) => i);
    shuffleArray(allFeatureIndices);
    const candidateFeatures = allFeatureIndices.slice(0, Math.min(numFeatures, this.maxFeatures));

    let bestGain = -Infinity;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    for (const feat of candidateFeatures) {
      // Collect unique values for this feature
      const values = indices.map((i) => X[i][feat]);
      values.sort((a, b) => a - b);

      // Candidate thresholds (pick up to 10 split points)
      const thresholds: number[] = [];
      const step = Math.max(1, Math.floor(values.length / 10));
      for (let k = step; k < values.length; k += step) {
        if (values[k] !== values[k - 1]) {
          thresholds.push((values[k] + values[k - 1]) / 2);
        }
      }

      for (const thr of thresholds) {
        const left: number[] = [];
        const right: number[] = [];
        let sumLeft = 0;
        let sumRight = 0;

        for (const idx of indices) {
          const val = X[idx][feat];
          if (val <= thr) {
            left.push(idx);
            sumLeft += y[idx];
          } else {
            right.push(idx);
            sumRight += y[idx];
          }
        }

        if (left.length < this.minSamplesLeaf || right.length < this.minSamplesLeaf) {
          continue;
        }

        const meanLeft = sumLeft / left.length;
        const meanRight = sumRight / right.length;

        let varLeft = 0;
        for (const idx of left) {
          const diff = y[idx] - meanLeft;
          varLeft += diff * diff;
        }

        let varRight = 0;
        for (const idx of right) {
          const diff = y[idx] - meanRight;
          varRight += diff * diff;
        }

        const gain = nodeVar - (varLeft + varRight);
        if (gain > bestGain) {
          bestGain = gain;
          bestFeature = feat;
          bestThreshold = thr;
          bestLeftIndices = left;
          bestRightIndices = right;
        }
      }
    }

    if (bestGain <= 0 || bestLeftIndices.length === 0 || bestRightIndices.length === 0) {
      return { isLeaf: true, value: meanY };
    }

    // Accumulate feature importance
    this.featureImportances[bestFeature] += bestGain;

    return {
      isLeaf: false,
      value: meanY,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: this.buildNode(X, y, bestLeftIndices, depth + 1),
      right: this.buildNode(X, y, bestRightIndices, depth + 1)
    };
  }

  public predictOne(x: number[]): number {
    let curr = this.root;
    while (curr && !curr.isLeaf) {
      if (curr.featureIndex === undefined || curr.threshold === undefined) break;
      if (x[curr.featureIndex] <= curr.threshold) {
        curr = curr.left ?? null;
      } else {
        curr = curr.right ?? null;
      }
    }
    return curr ? curr.value : 0;
  }
}

export class RandomForestModel {
  public trees: RegressionTree[] = [];
  public featureNames: string[] = [];
  public featureImportances: FeatureImportanceItem[] = [];
  public isTrained: boolean = false;

  constructor(
    public numTrees: number = 16,
    public maxDepth: number = 7,
    public minSamplesSplit: number = 4
  ) {}

  public train(X: number[][], y: number[], featureNames: string[]): void {
    const numSamples = X.length;
    if (numSamples === 0) throw new Error('Cannot train on empty dataset');
    const numFeatures = X[0].length;
    this.featureNames = featureNames;
    this.trees = [];

    const totalImp = new Array(numFeatures).fill(0);
    const maxFeatPerTree = Math.max(3, Math.floor(Math.sqrt(numFeatures) * 1.5));

    for (let t = 0; t < this.numTrees; t++) {
      // Bootstrap sampling (with replacement)
      const bootX: number[][] = [];
      const bootY: number[] = [];
      for (let i = 0; i < numSamples; i++) {
        const randIdx = Math.floor(Math.random() * numSamples);
        bootX.push(X[randIdx]);
        bootY.push(y[randIdx]);
      }

      const tree = new RegressionTree(this.maxDepth, this.minSamplesSplit, 2, maxFeatPerTree);
      tree.train(bootX, bootY);
      this.trees.push(tree);

      for (let j = 0; j < numFeatures; j++) {
        totalImp[j] += tree.featureImportances[j] || 0;
      }
    }

    // Normalize feature importances to sum to 100%
    const sumAll = totalImp.reduce((acc, v) => acc + v, 0) || 1;
    this.featureImportances = featureNames
      .map((name, idx) => ({
        feature: name,
        importance: Math.round(((totalImp[idx] || 0) / sumAll) * 1000) / 10,
        label: formatFeatureLabel(name)
      }))
      .sort((a, b) => b.importance - a.importance);

    this.isTrained = true;
  }

  public predict(features: number[]): number {
    if (!this.isTrained || this.trees.length === 0) {
      throw new Error('Random forest model has not been trained yet');
    }
    let sum = 0;
    for (const tree of this.trees) {
      sum += tree.predictOne(features);
    }
    return Math.max(0, Math.round(sum / this.trees.length));
  }
}

function shuffleArray(arr: number[]): void {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
}
