export interface LagResult {
  lag_1_demand: number;
  lag_7_demand: number;
  lag_30_demand: number;
}

/**
 * Computes strictly prior lag features for each record to prevent future leakage.
 */
export function computeLagFeatures<T extends { product_id: string; demand: number; previous_demand: number }>(
  records: T[],
  currentIndex: number
): LagResult {
  const currentRecord = records[currentIndex];
  const productId = currentRecord.product_id;

  // Search backward strictly before currentIndex for same product
  const priorDemands: number[] = [];
  for (let i = currentIndex - 1; i >= 0; i--) {
    if (records[i].product_id === productId) {
      priorDemands.push(records[i].demand);
      if (priorDemands.length >= 30) break;
    }
  }

  const defaultPrev = currentRecord.previous_demand || currentRecord.demand || 100;

  const lag_1_demand = priorDemands.length > 0 ? priorDemands[0] : defaultPrev;
  const lag_7_demand = priorDemands.length >= 7 ? priorDemands[6] : (priorDemands.length > 0 ? priorDemands[priorDemands.length - 1] : defaultPrev);
  const lag_30_demand = priorDemands.length >= 30 ? priorDemands[29] : (priorDemands.length > 0 ? priorDemands[priorDemands.length - 1] : defaultPrev);

  return {
    lag_1_demand,
    lag_7_demand,
    lag_30_demand
  };
}
