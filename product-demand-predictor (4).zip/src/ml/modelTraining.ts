import {
  ProcessedDemandRecord,
  ModelComparisonResult,
  LinearRegressionResult,
  RandomForestResult
} from '../types';
import {
  buildCategoricalMetadata,
  getFeatureColumnNames,
  encodeFeatureRow
} from './encoding';
import { LinearRegressionModel } from './linearRegression';
import { RandomForestModel } from './randomForest';
import { calculateMetrics } from '../utils/metrics';

export function trainAndEvaluateModels(records: ProcessedDemandRecord[]): ModelComparisonResult {
  if (records.length < 20) {
    throw new Error('Insufficient records to train models (at least 20 required).');
  }

  // 1. Categorical Metadata
  const metadata = buildCategoricalMetadata(records);
  const featureNames = getFeatureColumnNames(metadata);

  // 2. Chronological 80/20 Train/Test Split
  const splitIndex = Math.floor(records.length * 0.8);
  const trainRecords = records.slice(0, splitIndex);
  const testRecords = records.slice(splitIndex);

  // 3. Feature Encoding
  const X_train: number[][] = [];
  const y_train: number[] = [];
  for (const r of trainRecords) {
    X_train.push(encodeFeatureRow(r, metadata));
    y_train.push(r.demand);
  }

  const X_test: number[][] = [];
  const y_test: number[] = [];
  for (const r of testRecords) {
    X_test.push(encodeFeatureRow(r, metadata));
    y_test.push(r.demand);
  }

  // 4. Train Linear Regression
  const lrModel = new LinearRegressionModel(0.02);
  lrModel.train(X_train, y_train, featureNames);
  const lrTestPreds = X_test.map((x) => lrModel.predict(x));
  const lrEval = calculateMetrics(y_test, lrTestPreds);

  const linearRegressionResult: LinearRegressionResult = {
    evaluation: lrEval,
    featureNames,
    weights: lrModel.weights,
    bias: lrModel.bias,
    featureMeans: lrModel.featureMeans,
    featureStds: lrModel.featureStds,
    coefficients: lrModel.getCoefficients(),
    predict: (feats) => lrModel.predict(feats)
  };

  // 5. Train Random Forest Regression
  const rfModel = new RandomForestModel(16, 7, 4);
  rfModel.train(X_train, y_train, featureNames);
  const rfTestPreds = X_test.map((x) => rfModel.predict(x));
  const rfEval = calculateMetrics(y_test, rfTestPreds);

  const randomForestResult: RandomForestResult = {
    evaluation: rfEval,
    featureNames,
    featureImportances: rfModel.featureImportances,
    treeCount: rfModel.trees.length,
    predict: (feats) => rfModel.predict(feats)
  };

  // 6. Compare Models: Lower RMSE & higher R² indicates better performance
  const bestModel = rfEval.rmse <= lrEval.rmse ? 'Random Forest' : 'Linear Regression';

  return {
    linearRegression: linearRegressionResult,
    randomForest: randomForestResult,
    bestModel,
    trainSize: trainRecords.length,
    testSize: testRecords.length,
    featureNames,
    categories: metadata.categories,
    seasons: metadata.seasons
  };
}
