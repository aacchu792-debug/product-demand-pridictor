import React, { useState, useEffect } from 'react';
import {
  ProcessedDemandRecord,
  DatasetStatistics,
  ModelComparisonResult,
  PredictionOutput,
  DynamicInsight
} from './types';
import { fetchDefaultDataset, parseCsvString } from './services/dataset';
import { preprocessDataset } from './ml/preprocessing';
import { trainAndEvaluateModels } from './ml/modelTraining';
import { generateDynamicInsights } from './utils/insights';
import { ReportData } from './utils/reportGenerator';
import { Sidebar, NavigationPage } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { DemandPredictor } from './pages/DemandPredictor';
import { DemandAnalysis } from './pages/DemandAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import {
  Loader2,
  AlertCircle,
  Upload,
  RotateCcw,
  Sparkles,
  TrendingUp,
  X
} from 'lucide-react';

export function App() {
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard');
  const [records, setRecords] = useState<ProcessedDemandRecord[]>([]);
  const [stats, setStats] = useState<DatasetStatistics | null>(null);
  const [models, setModels] = useState<ModelComparisonResult | null>(null);
  const [insights, setInsights] = useState<DynamicInsight[]>([]);
  const [currentPrediction, setCurrentPrediction] = useState<PredictionOutput | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [loadingStep, setLoadingStep] = useState<string>('Loading Product Demand Dataset...');
  const [error, setError] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const loadAndTrain = async (customCsvText?: string) => {
    try {
      setIsLoading(true);
      setError(null);

      let rawRows: any[] = [];
      if (customCsvText) {
        setLoadingStep('Parsing uploaded CSV file...');
        rawRows = await parseCsvString(customCsvText);
      } else {
        setLoadingStep('Loading /data/product_demand.csv...');
        rawRows = await fetchDefaultDataset();
      }

      setLoadingStep('Cleaning dataset & engineering date/lag/rolling features...');
      // Yield to let UI update loading step
      await new Promise((r) => setTimeout(r, 60));

      const { records: processed, stats: datasetStats } = preprocessDataset(rawRows);
      setRecords(processed);
      setStats(datasetStats);

      setLoadingStep('Training Linear Regression & Random Forest models (80/20 chronological split)...');
      await new Promise((r) => setTimeout(r, 80));

      const modelResults = trainAndEvaluateModels(processed);
      setModels(modelResults);

      setLoadingStep('Generating dynamic business & performance insights...');
      const dynInsights = generateDynamicInsights(datasetStats, modelResults, processed);
      setInsights(dynInsights);

      setIsLoading(false);
    } catch (err: any) {
      console.error('Data load / ML pipeline error:', err);
      setError(err.message || 'Failed to process dataset or train machine learning models.');
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAndTrain();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        loadAndTrain(content);
      }
    };
    reader.readAsText(file);
  };

  const reportData: ReportData | null =
    stats && models
      ? {
          stats,
          models,
          prediction: currentPrediction,
          insights,
          records,
          chartElementId: 'demand-forecast-chart-container'
        }
      : null;

  const datasetDateRange =
    records.length > 0
      ? {
          start: records[0].date,
          end: records[records.length - 1].date
        }
      : undefined;

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col md:flex-row text-slate-900 font-sans antialiased">
      {/* Desktop Sidebar */}
      <div className="hidden md:block shrink-0">
        <Sidebar
          currentPage={currentPage}
          onSelectPage={(page) => {
            setCurrentPage(page);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          datasetDateRange={datasetDateRange}
          totalRecords={records.length}
        />
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[80vw] bg-slate-900 h-full z-10 flex flex-col">
            <div className="p-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-white text-sm">Product Demand ML</span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <Sidebar
                currentPage={currentPage}
                onSelectPage={(page) => {
                  setCurrentPage(page);
                  setMobileMenuOpen(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                datasetDateRange={datasetDateRange}
                totalRecords={records.length}
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        <Header
          currentPage={currentPage}
          reportData={reportData}
          onRefreshData={() => loadAndTrain()}
          onToggleMobileMenu={() => setMobileMenuOpen(true)}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto min-w-0">
          {/* Loading State */}
          {isLoading && (
            <div
              id="app-loading-state"
              className="py-24 flex flex-col items-center justify-center text-center space-y-4"
            >
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-sm">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <Loader2 className="w-6 h-6 text-emerald-600 animate-spin absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-sm" />
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  Running Local In-Browser Machine Learning Pipeline
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1 animate-pulse">
                  {loadingStep}
                </p>
              </div>

              <div className="w-64 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full animate-indeterminate" />
              </div>
            </div>
          )}

          {/* Error State */}
          {!isLoading && error && (
            <div
              id="app-error-state"
              className="p-6 bg-rose-50 border border-rose-200 rounded-2xl max-w-xl mx-auto my-12 text-center space-y-4"
            >
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-rose-900">
                  Application Initialization Error
                </h3>
                <p className="text-xs text-rose-700 mt-1">{error}</p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => loadAndTrain()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retry Default Dataset</span>
                </button>

                <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white border border-rose-300 text-rose-800 hover:bg-rose-50 text-xs font-semibold shadow-xs cursor-pointer transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>Upload CSV</span>
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
            </div>
          )}

          {/* Active View Rendering */}
          {!isLoading && !error && stats && models && (
            <div className="min-w-0">
              {currentPage === 'dashboard' && (
                <Dashboard
                  records={records}
                  stats={stats}
                  models={models}
                  insights={insights}
                  onNavigateToPredictor={() => {
                    setCurrentPage('predictor');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}

              {currentPage === 'predictor' && (
                <DemandPredictor
                  records={records}
                  stats={stats}
                  models={models}
                  currentPrediction={currentPrediction}
                  onPredictionChange={(pred) => setCurrentPrediction(pred)}
                />
              )}

              {currentPage === 'analysis' && (
                <DemandAnalysis records={records} stats={stats} />
              )}

              {currentPage === 'performance' && (
                <ModelPerformance comparison={models} insights={insights} />
              )}
            </div>
          )}
        </main>

        {/* Global Footer */}
        <footer className="bg-white border-t border-slate-200/90 py-5 px-6 text-center text-xs text-slate-500 mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div>
              <span className="font-semibold text-slate-700">Product Demand Predictor</span> • Frontend Machine Learning (Linear Regression & Random Forest)
            </div>
            <div className="text-[11px] text-slate-400">
              Educational & analytical estimation tool • 100% Client-side browser execution
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
export default App;
